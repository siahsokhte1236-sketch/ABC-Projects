import { ReactionRule, ReactionResult } from '../types';

export const NOBLE_GASES = ['He', 'Ne', 'Ar', 'Kr', 'Xe', 'Rn', 'Og'];

export const REACTION_RULES: ReactionRule[] = [
  // Core 26 Suggestions & Classics
  { id: 'water', reactants: ['H', 'O'], formula: 'H₂O', nameFa: 'آب', type: 'safe', anim: 'steam', color: '#38bdf8', hazard: 0, desc: 'ترکیب هیدروژن و اکسیژن تولید آب می‌کند؛ واکنشی که در پیل‌های سوختی هیدروژنی نیز استفاده می‌شود.' },
  { id: 'salt', reactants: ['Na', 'Cl'], formula: 'NaCl', nameFa: 'نمک طعام', type: 'crystal', anim: 'crystal', color: '#f1f5f9', hazard: 0, desc: 'سدیم و کلر با تشکیل پیوند یونی بسیار محکم، کریستال نمک خوراکی می‌سازند.' },
  { id: 'hcl', reactants: ['H', 'Cl'], formula: 'HCl', nameFa: 'هیدروژن کلرید', type: 'gas', anim: 'gas', color: '#a3e635', hazard: 1, desc: 'گاز هیدروژن کلرید تولید می‌شود که با حل شدن در آب، جوهر نمک (اسید کلریدریک) می‌سازد.' },
  { id: 'ammonia', reactants: ['H', 'N'], formula: 'NH₃', nameFa: 'آمونیاک', type: 'gas', anim: 'gas', color: '#93c5fd', hazard: 1, desc: 'ترکیب نیتروژن و هیدروژن فرآیند هابر را شبیه‌سازی می‌کند؛ گازی کلیدی در کودهای کشاورزی.' },
  { id: 'co2', reactants: ['C', 'O'], formula: 'CO₂', nameFa: 'دی‌اکسید کربن', type: 'gas', anim: 'gas', color: '#cbd5e1', hazard: 0, desc: 'سوختن کامل کربن در اکسیژن، گاز دی‌اکسید کربن تولید می‌کند.' },
  { id: 'methane', reactants: ['C', 'H'], formula: 'CH₄', nameFa: 'متان', type: 'fire', anim: 'fire', color: '#fb923c', hazard: 1, desc: 'متان ساده‌ترین هیدروکربن و جزء اصلی گاز طبیعی شهری است که به‌آسانی می‌سوزد.' },
  { id: 'rust', reactants: ['Fe', 'O'], formula: 'Fe₂O₃', nameFa: 'زنگ آهن (اکسید آهن)', type: 'color_change', anim: 'color', color: '#b45309', hazard: 0, desc: 'آهن در مجاورت اکسیژن و رطوبت اکسید شده و لایه‌ای نارنجی-قهوه‌ای می‌سازد.' },
  { id: 'cuo', reactants: ['Cu', 'O'], formula: 'CuO', nameFa: 'اکسید مس', type: 'color_change', anim: 'color', color: '#1e293b', hazard: 0, desc: 'مس با اکسیژن داغ واکنش داده و اکسید مس سیاه‌رنگ ایجاد می‌کند.' },
  { id: 'mgo', reactants: ['Mg', 'O'], formula: 'MgO', nameFa: 'اکسید منیزیم', type: 'fire', anim: 'fire', color: '#f8fafc', hazard: 1, desc: 'منیزیم با نوری خیره‌کننده و سفید می‌سوزد و پودر سفید اکسید منیزیم باقی می‌گذارد.' },
  { id: 'so2', reactants: ['S', 'O'], formula: 'SO₂', nameFa: 'دی‌اکسید گوگرد', type: 'gas', anim: 'gas', color: '#fde047', hazard: 1, desc: 'گوگرد با شعله‌ای آبی‌رنگ در اکسیژن می‌سوزد و گازی با بوی تند و تحریک‌کننده می‌سازد.' },
  { id: 'h2s', reactants: ['H', 'S'], formula: 'H₂S', nameFa: 'هیدروژن سولفید', type: 'gas', anim: 'gas', color: '#a3a94f', hazard: 1, desc: 'گازی سمی با بوی معروف تخم‌مرغ فاسد که در چشمه‌های آبگرم گوگردی یافت می‌شود.' },
  { id: 'sio2', reactants: ['Si', 'O'], formula: 'SiO₂', nameFa: 'سیلیس (شن و کوارتز)', type: 'crystal', anim: 'crystal', color: '#c4b5fd', hazard: 0, desc: 'سیلیسیم و اکسیژن، شبکه بلوری سیلیس را می‌سازند؛ ماده اولیه شیشه و سنگ کوارتز.' },
  { id: 'cao', reactants: ['Ca', 'O'], formula: 'CaO', nameFa: 'آهک زنده', type: 'glow', anim: 'glow', color: '#fef3c7', hazard: 1, desc: 'اکسید کلسیم (آهک زنده) که در واکنش با آب گرمای زیادی آزاد می‌کند.' },
  { id: 'al2o3', reactants: ['Al', 'O'], formula: 'Al₂O₃', nameFa: 'اکسید آلومینیم (آلومینا)', type: 'crystal', anim: 'crystal', color: '#a5f3fc', hazard: 0, desc: 'ترکیبی فوق‌العاده سخت؛ سنگ‌های قیمتی یاقوت و زمرد ساختار بلوری آلومینا دارند.' },
  { id: 'na2o', reactants: ['Na', 'O'], formula: 'Na₂O', nameFa: 'اکسید سدیم', type: 'fire', anim: 'fire', color: '#fbbf24', hazard: 1, desc: 'سدیم فلزی شدیداً واکنش‌پذیر است و در هوا به‌سرعت اکسید می‌شود.' },
  { id: 'k2o', reactants: ['K', 'O'], formula: 'K₂O', nameFa: 'اکسید پتاسیم', type: 'fire', anim: 'fire', color: '#f472b6', hazard: 1, desc: 'پتاسیم با شعله بنفش‌رنگ واکنش داده و اکسید پتاسیم تولید می‌کند.' },
  { id: 'no', reactants: ['N', 'O'], formula: 'NO', nameFa: 'نیتریک اکسید', type: 'gas', anim: 'electric', color: '#a78bfa', hazard: 1, desc: 'در دماهای فوق‌العاده بالا (مثل جرقه آذرخش)، نیتروژن و اکسیژن هوا ترکیب می‌شوند.' },
  { id: 'ags', reactants: ['Ag', 'S'], formula: 'Ag₂S', nameFa: 'سولفید نقره', type: 'color_change', anim: 'color', color: '#334155', hazard: 0, desc: 'علت تیره شدن ظروف و زیورآلات نقره در هوا، تشکیل لایه سولفید نقره است.' },
  { id: 'fes', reactants: ['Fe', 'S'], formula: 'FeS', nameFa: 'سولفید آهن', type: 'color_change', anim: 'color', color: '#3f3f46', hazard: 0, desc: 'ترکیب مستقیم براده آهن و گوگرد داغ، ماده سیاه‌رنگ سولفید آهن می‌دهد.' },
  { id: 'hf', reactants: ['H', 'F'], formula: 'HF', nameFa: 'هیدروژن فلورید', type: 'gas', anim: 'gas', color: '#bef264', hazard: 2, desc: 'فوق‌العاده خورنده؛ اسیدی که توانایی حکاکی و ذوب کردن شیشه را دارد.' },
  { id: 'brass', reactants: ['Cu', 'Zn'], formula: 'Cu+Zn', nameFa: 'آلیاژ برنج', type: 'safe', anim: 'glow', color: '#facc15', hazard: 0, desc: 'ذوب و ترکیب مس و روی، آلیاژ برنج زردرنگ و خوش‌تراش را می‌سازد.' },
  { id: 'bronze', reactants: ['Cu', 'Sn'], formula: 'Cu+Sn', nameFa: 'آلیاژ برنز', type: 'safe', anim: 'glow', color: '#d97706', hazard: 0, desc: 'ترکیب تاریخی مس و قلع که پایه عصر مفرغ انسان‌های باستان بود.' },
  { id: 'steel', reactants: ['Fe', 'C'], formula: 'Fe+C', nameFa: 'فولاد (آلیاژ آهن و کربن)', type: 'safe', anim: 'glow', color: '#94a3b8', hazard: 0, desc: 'افزودن درصد کمی کربن به آهن، استحکام آن را صدها برابر کرده و فولاد می‌سازد.' },
  { id: 'amalgam', reactants: ['Au', 'Hg'], formula: 'Au+Hg', nameFa: 'آمالگام طلا', type: 'unstable', anim: 'glow', color: '#eab308', hazard: 2, desc: 'جیوه مایع طلا را در خود حل کرده و آمالگام خمیری‌شکل می‌سازد.' },
  { id: 'li2o', reactants: ['Li', 'O'], formula: 'Li₂O', nameFa: 'اکسید لیتیم', type: 'fire', anim: 'fire', color: '#ef4444', hazard: 1, desc: 'لیتیم با شعله سرخ ارغوانی می‌سوزد و اکسید لیتیم می‌سازد.' },
  { id: 'cso2', reactants: ['Cs', 'O'], formula: 'CsO₂', nameFa: 'سوپراکسید سزیم', type: 'fire', anim: 'fire', color: '#f97316', hazard: 2, desc: 'سزیم واکنش‌پذیرترین فلز پایدار است که خودبه‌خود در هوا مشتعل می‌شود!' },
  { id: 'rbcl', reactants: ['Rb', 'Cl'], formula: 'RbCl', nameFa: 'کلرید روبیدیم', type: 'fire', anim: 'fire', color: '#fb7185', hazard: 1, desc: 'واکنش شدید روبیدیم با گاز کلر همراه با نور بنفش و نمک سفید.' },
  { id: 'cacl2', reactants: ['Ca', 'Cl'], formula: 'CaCl₂', nameFa: 'کلرید کلسیم', type: 'crystal', anim: 'crystal', color: '#f1f5f9', hazard: 0, desc: 'نمک جاذب قوی رطوبت که برای یخ‌زدایی جاده‌ها استفاده می‌شود.' },
  { id: 'mg3n2', reactants: ['Mg', 'N'], formula: 'Mg₃N₂', nameFa: 'نیترید منیزیم', type: 'glow', anim: 'glow', color: '#fef08a', hazard: 1, desc: 'منیزیم داغ حتی توانایی سوزاندن گاز نیتروژن هوا را دارد.' },
  { id: 'ali3', reactants: ['Al', 'I'], formula: 'AlI₃', nameFa: 'یدید آلومینیم', type: 'fire', anim: 'gas', color: '#a855f7', hazard: 1, desc: 'واکنش نمایشی کلاسی معروف با تولید دود بنفش‌رنگ ید.' },
  { id: 'zns', reactants: ['Zn', 'S'], formula: 'ZnS', nameFa: 'سولفید روی', type: 'glow', anim: 'glow', color: '#d9f99d', hazard: 0, desc: 'ماده فسفرسانس شب‌تاب که در ساعت‌های قدیمی و صفحات پرتو ایکس کاربرد داشت.' },
  { id: 'sro', reactants: ['Sr', 'O'], formula: 'SrO', nameFa: 'اکسید استرانسیم', type: 'fire', anim: 'fire', color: '#dc2626', hazard: 1, desc: 'عنصر مسئول ایجاد رنگ سرخ آتش‌بازی‌های جشن.' },
  { id: 'bao2', reactants: ['Ba', 'O'], formula: 'BaO₂', nameFa: 'پراکسید باریم', type: 'fire', anim: 'fire', color: '#22c55e', hazard: 1, desc: 'باریم رنگ سبز زمردی در نورافشانی آسمان ایجاد می‌کند.' },
  { id: 'cucl2', reactants: ['Cu', 'Cl'], formula: 'CuCl₂', nameFa: 'کلرید مس', type: 'gas', anim: 'gas', color: '#06b6d4', hazard: 1, desc: 'شعله سبز-آبی مس در حضور کلر.' },
  { id: 'tio2', reactants: ['Ti', 'O'], formula: 'TiO₂', nameFa: 'دی‌اکسید تیتانیم', type: 'color_change', anim: 'color', color: '#f8fafc', hazard: 0, desc: 'سفیدترین ماده شناخته‌شده روی زمین؛ رنگدانه اصلی ضدآفتاب و خمیردندان.' },
  { id: 'pbo', reactants: ['Pb', 'O'], formula: 'PbO', nameFa: 'اکسید سرب (لتارج)', type: 'color_change', anim: 'color', color: '#f59e0b', hazard: 1, desc: 'اکسید زرد-نارنجی سرب که در گذشته در کریستال‌سازی کاربرد داشت.' },
  { id: 'hgs', reactants: ['Hg', 'S'], formula: 'HgS', nameFa: 'شنگرف (سینابر)', type: 'color_change', anim: 'color', color: '#e11d48', hazard: 1, desc: 'کانی سرخ درخشان جیوه که در نقاشی‌های قدیم به عنوان رنگدانه استفاده می‌شد.' },
  { id: 'ki', reactants: ['K', 'I'], formula: 'KI', nameFa: 'یدید پتاسیم', type: 'crystal', anim: 'crystal', color: '#e9d5ff', hazard: 0, desc: 'ترکیب دارویی محافظ تیروئید در برابر تابش‌های هسته‌ای.' },
  { id: 'agcl', reactants: ['Ag', 'Cl'], formula: 'AgCl', nameFa: 'کلرید نقره', type: 'crystal', anim: 'crystal', color: '#f1f5f9', hazard: 0, desc: 'رسوب سفید حساس به نور که پایه صنعت عکاسی آنالوگ بود.' },
  { id: 'ptf6', reactants: ['Pt', 'F'], formula: 'PtF₆', nameFa: 'هگزافلورید پلاتین', type: 'gas', anim: 'gas', color: '#fde68a', hazard: 2, desc: 'اکسیدکننده قدرتمندی که برای اولین بار گاز نجیب گزنون را وادار به واکنش کرد!' },
  { id: 'xef2', reactants: ['Xe', 'F'], formula: 'XeF₂', nameFa: 'دی‌فلورید گزنون', type: 'crystal', anim: 'glow', color: '#c7d2fe', hazard: 1, desc: 'اولین ترکیب کشف‌شده از یک گاز نجیب که فرضیه بی‌اثری مطلق را شکست.' },
  { id: 'krf2', reactants: ['Kr', 'F'], formula: 'KrF₂', nameFa: 'دی‌فلورید کریپتون', type: 'gas', anim: 'gas', color: '#a5f3fc', hazard: 2, desc: 'ترکیب ناپایدار کریپتون با واکنش‌پذیرترین عنصر جهان.' },
  { id: 'sic', reactants: ['Si', 'C'], formula: 'SiC', nameFa: 'کاربید سیلیسیم (کاربوراندوم)', type: 'crystal', anim: 'crystal', color: '#a3e635', hazard: 0, desc: 'ماده‌ای نزدیک به سختی الماس که در ترمز خودروهای مسابقه‌ای استفاده می‌شود.' },
  { id: 'cac2', reactants: ['Ca', 'C'], formula: 'CaC₂', nameFa: 'کاربید کلسیم', type: 'glow', anim: 'glow', color: '#fbbf24', hazard: 1, desc: 'ماده‌ای که در تماس با آب، گاز استیلن جوشکاری آزاد می‌کند.' },
  { id: 'feni', reactants: ['Fe', 'Ni'], formula: 'Fe+Ni', nameFa: 'آلیاژ اینوار (آهن و نیکل)', type: 'safe', anim: 'glow', color: '#cbd5e1', hazard: 0, desc: 'آلیاژی با ضریب انبساط گرمایی نزدیک به صفر برای ابزارهای اندازه‌گیری بسیار دقیق.' },
  { id: 'hno3', reactants: ['H', 'N', 'O'], formula: 'HNO₃', nameFa: 'اسید نیتریک (جوهر شوره)', type: 'gas', anim: 'electric', color: '#bef264', hazard: 2, desc: 'اسید قوی تشکیل‌شده از سه عنصر اصلی جو و آب.' },
  { id: 'sugar', reactants: ['C', 'H', 'O'], formula: 'C₆H₁₂O₆', nameFa: 'قند گلوکز', type: 'crystal', anim: 'crystal', color: '#fef9c3', hazard: 0, desc: 'ترکیب حیات‌بخش سه عنصر کربن، هیدروژن و اکسیژن.' },
  { id: 'dural', reactants: ['Al', 'Cu', 'Mg'], formula: 'Al+Cu+Mg', nameFa: 'دورآلومین (آلیاژ بدنه هواپیما)', type: 'safe', anim: 'glow', color: '#93c5fd', hazard: 0, desc: 'آلیاژ فوق‌العاده سبک و مقاوم آلومینیم، مس و منیزیم.' },
  { id: 'noble1', reactants: ['He', 'Ne'], formula: '—', nameFa: 'بدون واکنش (گازهای نجیب)', type: 'no_reaction', anim: 'none', color: '#64748b', hazard: 0, desc: 'گازهای نجیب هلیوم و نئون مدار الکترونی پر دارند و ترکیبی تشکیل نمی‌دهند.' },
  { id: 'noble2', reactants: ['Ar', 'Xe'], formula: '—', nameFa: 'بدون واکنش (گازهای نجیب)', type: 'no_reaction', anim: 'none', color: '#64748b', hazard: 0, desc: 'آرگون و گزنون در شرایط عادی کاملاً بی‌اثر باقی می‌مانند.' }
];

export const UNKNOWN_REACTION_RULE: ReactionRule = {
  id: 'unknown',
  reactants: [],
  formula: null,
  nameFa: 'واکنش غیرمنتظره و ناپایدار!',
  type: 'explosion',
  anim: 'explosion',
  color: '#f97316',
  hazard: 3,
  desc: 'این ترکیب عناصر در پایگاه داده واکنش داده نشد! واکنش شدید و کنترل‌نشده‌ای رخ داد و ظرف آزمایشگاه آسیب دید.'
};

export const INERT_REACTION_RULE: ReactionRule = {
  id: 'inert',
  reactants: [],
  formula: '—',
  nameFa: 'بدون واکنش (حضور گاز نجیب)',
  type: 'no_reaction',
  anim: 'none',
  color: '#64748b',
  hazard: 0,
  desc: 'حداقل یکی از عناصر گاز نجیب است؛ گازهای نجیب به دلیل آرایش الکترونی کامل، واکنش نمی‌دهند.'
};

export function resolveReaction(symbols: string[]): ReactionResult {
  const norm = Array.from(new Set(symbols.map(s => s.trim())));
  const key = norm.slice().sort().join('+');

  const match = REACTION_RULES.find(r => r.reactants.slice().sort().join('+') === key);
  if (match) {
    return { status: 'known', rule: match, symbols: norm };
  }

  const hasNoble = norm.some(s => NOBLE_GASES.includes(s));
  if (hasNoble && norm.length >= 2) {
    return {
      status: 'inert',
      rule: { ...INERT_REACTION_RULE, reactants: norm },
      symbols: norm
    };
  }

  return {
    status: 'unknown',
    rule: { ...UNKNOWN_REACTION_RULE, reactants: norm },
    symbols: norm
  };
}

// 26 Preset Quick Experiment IDs for suggested list
export const SUGGESTED_EXPERIMENT_IDS = [
  'water', 'salt', 'li2o', 'cso2', 'rbcl', 'cacl2', 'mg3n2', 'ali3',
  'zns', 'sro', 'bao2', 'cucl2', 'tio2', 'pbo', 'hgs', 'ki',
  'agcl', 'ptf6', 'xef2', 'krf2', 'sic', 'cac2', 'feni', 'hno3',
  'sugar', 'dural'
];
