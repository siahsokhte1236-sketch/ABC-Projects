import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { ChemicalElement, ElementCategoryKey, HeatmapMode } from './types';
import { ELEMENTS } from './data/elements';
import { Header } from './components/Header';
import { Toolbar } from './components/Toolbar';
import { PeriodicTable } from './components/PeriodicTable';
import { ElementTooltip } from './components/ElementTooltip';
import { ElementModal } from './components/ElementModal';
import { Lab3D } from './components/Lab3D';
import { Dock } from './components/Dock';
import { toggleSound, isSoundEnabled } from './utils/audio';

export default function App() {
  const [activeView, setActiveView] = useState<'table' | 'lab'>('table');
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [soundOn, setSoundOn] = useState(isSoundEnabled());

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<ElementCategoryKey | 'all'>('all');
  const [blockFilter, setBlockFilter] = useState<'s' | 'p' | 'd' | 'f' | 'all'>('all');
  const [heatmapMode, setHeatmapMode] = useState<HeatmapMode>('none');

  // Modal & Tooltip State
  const [selectedElement, setSelectedElement] = useState<ChemicalElement | null>(null);
  const [hoveredElement, setHoveredElement] = useState<ChemicalElement | null>(null);
  const [tooltipPos, setTooltipPos] = useState<{ x: number; y: number } | null>(null);

  // Sync theme attribute with html element
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  // Deep linking via hash `#element=Z`
  useEffect(() => {
    const handleHash = () => {
      const match = window.location.hash.match(/element=(\d+)/);
      if (match) {
        const z = parseInt(match[1], 10);
        const found = ELEMENTS.find(e => e.z === z);
        if (found) {
          setSelectedElement(found);
        }
      }
    };

    handleHash();
    window.addEventListener('hashchange', handleHash);
    return () => window.removeEventListener('hashchange', handleHash);
  }, []);

  // Filter matching element count
  const matchedCount = useMemo(() => {
    return ELEMENTS.filter(el => {
      if (categoryFilter !== 'all' && el.cat !== categoryFilter) return false;
      if (blockFilter !== 'all' && el.cfg.block !== blockFilter) return false;
      if (searchQuery.trim() !== '') {
        const q = searchQuery.trim().toLowerCase();
        const matchFa = el.fa.toLowerCase().includes(q);
        const matchEn = el.en.toLowerCase().includes(q);
        const matchSym = el.sym.toLowerCase().startsWith(q);
        const matchZ = String(el.z) === q || String(el.z).startsWith(q);
        if (!matchFa && !matchEn && !matchSym && !matchZ) return false;
      }
      return true;
    }).length;
  }, [searchQuery, categoryFilter, blockFilter]);

  const handleResetFilters = () => {
    setSearchQuery('');
    setCategoryFilter('all');
    setBlockFilter('all');
    setHeatmapMode('none');
  };

  const handleHoverElement = useCallback((element: ChemicalElement | null, event?: React.MouseEvent) => {
    setHoveredElement(element);
    if (element && event) {
      setTooltipPos({ x: event.clientX, y: event.clientY });
    } else {
      setTooltipPos(null);
    }
  }, []);

  const handleOpenModal = useCallback((element: ChemicalElement) => {
    setSelectedElement(element);
    try {
      window.history.replaceState(null, '', `#element=${element.z}`);
    } catch (e) {
      window.location.hash = `element=${element.z}`;
    }
  }, []);

  const handleCloseModal = useCallback(() => {
    setSelectedElement(null);
    try {
      window.history.replaceState(null, '', window.location.pathname + window.location.search);
    } catch (e) {
      window.location.hash = '';
    }
  }, []);

  const handleModalNavigate = useCallback((direction: 'prev' | 'next') => {
    if (!selectedElement) return;
    const currentZ = selectedElement.z;
    const targetZ = direction === 'prev' ? currentZ - 1 : currentZ + 1;
    const targetElement = ELEMENTS.find(e => e.z === targetZ);
    if (targetElement) {
      handleOpenModal(targetElement);
    }
  }, [selectedElement, handleOpenModal]);

  return (
    <div className={`app-shell min-h-screen ${theme === 'dark' ? 'text-slate-100' : 'text-slate-900'} transition-colors duration-300 pb-20`}>
      
      {/* Top Header */}
      <Header
        activeView={activeView}
        onViewChange={setActiveView}
        theme={theme}
        onToggleTheme={() => setTheme(t => t === 'dark' ? 'light' : 'dark')}
        soundEnabled={soundOn}
        onToggleSound={() => setSoundOn(toggleSound())}
      />

      {/* Main View Area */}
      <main className="max-w-7xl mx-auto px-3 sm:px-6 py-6">
        
        {activeView === 'table' ? (
          <div>
            <Toolbar
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
              categoryFilter={categoryFilter}
              onCategoryFilterChange={setCategoryFilter}
              blockFilter={blockFilter}
              onBlockFilterChange={setBlockFilter}
              heatmapMode={heatmapMode}
              onHeatmapModeChange={setHeatmapMode}
              onReset={handleResetFilters}
              matchCount={matchedCount}
              totalCount={ELEMENTS.length}
            />

            {matchedCount === 0 ? (
              <div className="glass-panel rounded-2xl p-12 text-center space-y-2 border border-slate-800">
                <div className="text-4xl">🔎</div>
                <div className="text-lg font-bold text-slate-300">عنصری با این مشخصات یافت نشد</div>
                <p className="text-xs text-slate-400">لطفاً عبارت دیگری را جستجو کنید یا فیلترها را بازنشانی فرمایید.</p>
                <button
                  onClick={handleResetFilters}
                  className="mt-3 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow-lg"
                >
                  بازنشانی فیلترها
                </button>
              </div>
            ) : (
              <PeriodicTable
                elements={ELEMENTS}
                searchQuery={searchQuery}
                categoryFilter={categoryFilter}
                blockFilter={blockFilter}
                heatmapMode={heatmapMode}
                onSelectElement={handleOpenModal}
                onHoverElement={handleHoverElement}
              />
            )}
          </div>
        ) : (
          <Lab3D elements={ELEMENTS} />
        )}

      </main>

      {/* Footer */}
      <footer className="max-w-7xl mx-auto px-4 py-6 text-center text-xs text-slate-400 border-t border-slate-800/60 mt-8 space-y-1">
        <p>داده‌های علمی بر اساس مرجع بین‌المللی شیمی ناپیوسته (IUPAC)، PubChem و پایگاه‌های آموزشی استاندارد تهیه‌شده‌اند.</p>
        <p className="text-slate-400">طراحی و پیاده‌سازی متناسب با استاندارد‌های رابط کاربری مدرن فارسی</p>
      </footer>

      {/* Floating Hover Tooltip */}
      <ElementTooltip element={hoveredElement} position={tooltipPos} />

      {/* Element Detail Modal */}
      <ElementModal
        element={selectedElement}
        onClose={handleCloseModal}
        onNavigate={handleModalNavigate}
        hasPrev={selectedElement ? selectedElement.z > 1 : false}
        hasNext={selectedElement ? selectedElement.z < 118 : false}
      />

      {/* Floating Bottom View Dock */}
      <Dock activeView={activeView} onViewChange={setActiveView} />

    </div>
  );
}
