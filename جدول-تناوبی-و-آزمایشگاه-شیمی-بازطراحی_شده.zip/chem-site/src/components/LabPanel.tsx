import React, { useState } from 'react';
import { ChemicalElement, ReactionResult, LabHistoryItem, ElementCategoryKey } from '../types';
import { CATEGORIES } from '../data/categories';
import { REACTION_RULES, SUGGESTED_EXPERIMENT_IDS } from '../data/reactions';
import { EducationalSafetyCard } from './EducationalSafetyCard';
import {
  Search, Flame, Trash2, Camera, Wrench, RotateCcw,
  Sparkles, Shuffle, BookOpen, FlaskConical, History,
  ShieldCheck, Info
} from 'lucide-react';
import { playClickSound, playDropSound, playRepairSound } from '../utils/audio';

interface LabPanelProps {
  elements: ChemicalElement[];
  selectedElements: ChemicalElement[];
  onAddElement: (el: ChemicalElement) => void;
  onRemoveElement: (index: number) => void;
  onClearVessel: () => void;
  onResetCamera: () => void;
  onRepairVessel: () => void;
  onRunReaction: () => void;
  onRunPresetRule: (reactants: string[]) => void;
  isVesselDestroyed: boolean;
  isBusy: boolean;
  lastResult: ReactionResult | null;
  history: LabHistoryItem[];
  onReplayHistory: (item: LabHistoryItem) => void;
}

export const LabPanel: React.FC<LabPanelProps> = ({
  elements,
  selectedElements,
  onAddElement,
  onRemoveElement,
  onClearVessel,
  onResetCamera,
  onRepairVessel,
  onRunReaction,
  onRunPresetRule,
  isVesselDestroyed,
  isBusy,
  lastResult,
  history,
  onReplayHistory,
}) => {
  const [activeTab, setActiveTab] = useState<'workbench' | 'presets' | 'knowledge'>('workbench');
  const [search, setSearch] = useState('');
  const [catFilter, setCatFilter] = useState<ElementCategoryKey | 'all'>('all');
  const [presetCategory, setPresetCategory] = useState<'all' | 'hazard' | 'fire' | 'gas' | 'crystal'>('all');
  const [infoElement, setInfoElement] = useState<ChemicalElement | null>(elements[0] || null);

  // Filter elements
  const filteredElements = elements.filter(el => {
    if (catFilter !== 'all' && el.cat !== catFilter) return false;
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      return (
        el.fa.toLowerCase().includes(q) ||
        el.en.toLowerCase().includes(q) ||
        el.sym.toLowerCase().startsWith(q) ||
        String(el.z) === q
      );
    }
    return true;
  });

  const presetRules = SUGGESTED_EXPERIMENT_IDS.map(id =>
    REACTION_RULES.find(r => r.id === id)
  ).filter(Boolean);

  const filteredPresetRules = presetRules.filter(r => {
    if (!r) return false;
    if (presetCategory === 'hazard') return r.hazard >= 1;
    if (presetCategory === 'fire') return r.anim === 'fire' || r.type === 'fire';
    if (presetCategory === 'gas') return r.anim === 'gas' || r.type === 'gas';
    if (presetCategory === 'crystal') return r.anim === 'crystal' || r.type === 'crystal' || r.type === 'safe';
    return true;
  });

  const runRandomPreset = () => {
    playClickSound();
    const rand = presetRules[Math.floor(Math.random() * presetRules.length)];
    if (rand) {
      onRunPresetRule(rand.reactants);
    }
  };

  return (
    <div className="w-full lg:w-[380px] h-full flex flex-col bg-black/40 border-l border-white/5 p-3.5 space-y-3 dir-rtl text-slate-100 backdrop-blur-2xl">

      {/* Sleek Tab Navigation */}
      <div className="grid grid-cols-3 gap-1 bg-black/30 p-1.5 rounded-2xl border border-white/5 shadow-inner">
        <button
          onClick={() => { playClickSound(); setActiveTab('workbench'); }}
          className={`flex items-center justify-center gap-1.5 py-2 px-1 rounded-xl text-xs font-black transition-all ${
            activeTab === 'workbench'
              ? 'bg-teal-500 text-slate-950 shadow-md shadow-teal-950/40'
              : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
          }`}
        >
          <FlaskConical className="w-3.5 h-3.5" />
          <span>میز کار</span>
        </button>

        <button
          onClick={() => { playClickSound(); setActiveTab('presets'); }}
          className={`flex items-center justify-center gap-1.5 py-2 px-1 rounded-xl text-xs font-black transition-all ${
            activeTab === 'presets'
              ? 'bg-teal-500 text-slate-950 shadow-md shadow-teal-950/40'
              : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-300" />
          <span>۲۶ آزمایش</span>
        </button>

        <button
          onClick={() => { playClickSound(); setActiveTab('knowledge'); }}
          className={`flex items-center justify-center gap-1.5 py-2 px-1 rounded-xl text-xs font-black transition-all ${
            activeTab === 'knowledge'
              ? 'bg-teal-500 text-slate-950 shadow-md shadow-teal-950/40'
              : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5" />
          <span>علمی و ایمنی</span>
        </button>
      </div>

      {/* VIEW 1: WORKBENCH & ELEMENT MIXING */}
      {activeTab === 'workbench' && (
        <div className="flex-1 flex flex-col space-y-3 overflow-y-auto pr-0.5 scrollbar-thin">

          {/* Action Control Hub */}
          <div className="glass-card p-3 rounded-2xl bg-black/20 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-extrabold text-teal-400 flex items-center gap-1.5">
                <span>🧪</span>
                <span>ترکیب و کنترل ظرف آزمایش</span>
              </span>
              <button
                onClick={() => { playClickSound(); onResetCamera(); }}
                className="p-1.5 bg-white/[0.04] hover:bg-white/10 text-slate-300 rounded-lg border border-white/5 transition-colors"
                title="بازنشانی زاویه دوربین"
              >
                <Camera className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Vessel Contents */}
            <div className="bg-black/30 p-2.5 rounded-xl border border-white/5 space-y-1.5">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-amber-400 font-bold">عناصر انتخاب‌شده ({selectedElements.length} از ۴):</span>
                {selectedElements.length > 0 && (
                  <button
                    onClick={() => { playClickSound(); onClearVessel(); }}
                    className="text-red-400 hover:text-red-300 font-semibold flex items-center gap-1 transition-colors"
                  >
                    <Trash2 className="w-3 h-3" />
                    <span>خالی کردن</span>
                  </button>
                )}
              </div>

              {selectedElements.length === 0 ? (
                <div className="text-center py-2.5 text-[11px] text-slate-500 border border-dashed border-white/10 rounded-lg">
                  عنصری در ظرف نیست؛ از کاتالوگ زیر انتخاب کنید.
                </div>
              ) : (
                <div className="flex flex-wrap gap-1.5">
                  {selectedElements.map((el, idx) => {
                    const cat = CATEGORIES[el.cat];
                    return (
                      <div
                        key={idx}
                        onClick={() => {
                          playClickSound();
                          setInfoElement(el);
                        }}
                        style={{ backgroundColor: cat.color }}
                        className="flex items-center gap-1 px-2.5 py-0.5 rounded-full text-slate-950 text-xs font-black shadow-sm cursor-pointer hover:brightness-110 transition-all"
                        title="کلیک برای اطلاعات علمی این عنصر"
                      >
                        <span className="font-mono">{el.sym}</span>
                        <span className="text-[10px] opacity-80">{el.fa}</span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            playClickSound();
                            onRemoveElement(idx);
                          }}
                          className="w-3.5 h-3.5 rounded-full bg-black/20 hover:bg-black/40 text-slate-900 flex items-center justify-center text-[9px] mr-0.5"
                        >
                          ✕
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Run / Repair Button */}
            {isVesselDestroyed ? (
              <button
                onClick={() => { playRepairSound(); onRepairVessel(); }}
                className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-600 to-red-600 text-white font-black text-xs shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 hover:brightness-110 active:scale-95 transition-all"
              >
                <Wrench className="w-4 h-4 animate-bounce" />
                <span>🔧 بازسازی ظرف شکسته‌شده</span>
              </button>
            ) : (
              <button
                onClick={() => { playClickSound(); onRunReaction(); }}
                disabled={isBusy || selectedElements.length < 2}
                className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-teal-600 to-cyan-600 hover:from-teal-500 hover:to-cyan-500 text-white font-black text-xs shadow-lg shadow-teal-500/20 flex items-center justify-center gap-2 disabled:opacity-40 disabled:pointer-events-none active:scale-95 transition-all"
              >
                <Flame className="w-4 h-4 text-amber-300" />
                <span>شروع واکنش و ترکیب مواد</span>
              </button>
            )}
          </div>

          {/* Element Picker */}
          <div className="glass-card p-3 rounded-2xl bg-black/20 space-y-2 flex-1 flex flex-col">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-300">انتخاب عناصر از جدول</span>
              <span className="text-[10px] text-slate-500">مجموع ۱۱۸ عنصر</span>
            </div>

            {/* Search & Categories */}
            <div className="space-y-1.5">
              <div className="relative">
                <Search className="absolute right-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-500 pointer-events-none" />
                <input
                  type="search"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="جستجوی عنصر (مثال: H, اکسیژن, 11)..."
                  className="w-full pr-7 pl-2.5 py-1 bg-black/30 border border-white/10 focus:border-teal-500/60 rounded-xl text-xs text-slate-200 placeholder-slate-500 focus:outline-none"
                />
              </div>

              <div className="flex flex-wrap gap-1 max-h-12 overflow-y-auto scrollbar-none">
                <button
                  onClick={() => setCatFilter('all')}
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold border transition-all ${
                    catFilter === 'all'
                      ? 'bg-teal-500 text-slate-950 border-teal-300 font-extrabold'
                      : 'bg-black/20 text-slate-400 border-white/5'
                  }`}
                >
                  همه
                </button>
                {(Object.keys(CATEGORIES) as ElementCategoryKey[]).map(catKey => (
                  <button
                    key={catKey}
                    onClick={() => setCatFilter(catKey)}
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold border transition-all ${
                      catFilter === catKey
                        ? 'bg-white/[0.06] text-white border-teal-400/70'
                        : 'bg-black/15 text-slate-400 border-white/5'
                    }`}
                  >
                    {CATEGORIES[catKey].fa}
                  </button>
                ))}
              </div>
            </div>

            {/* Grid */}
            <div className="grid grid-cols-4 sm:grid-cols-5 gap-1.5 max-h-56 overflow-y-auto p-1 scrollbar-thin">
              {filteredElements.map((el) => {
                const cat = CATEGORIES[el.cat];
                const isSelectedForInfo = infoElement?.z === el.z;
                return (
                  <div key={el.z} className="relative group">
                    <button
                      onClick={() => {
                        playDropSound();
                        onAddElement(el);
                        setInfoElement(el);
                      }}
                      disabled={isBusy || isVesselDestroyed || selectedElements.length >= 4}
                      style={{ backgroundColor: cat.color }}
                      className={`w-full flex flex-col items-center justify-center p-1.5 rounded-xl text-slate-950 font-black hover:scale-105 active:scale-95 transition-all disabled:opacity-30 disabled:pointer-events-none shadow-sm ${
                        isSelectedForInfo ? 'ring-2 ring-teal-400 ring-offset-2 ring-offset-black' : ''
                      }`}
                    >
                      <span className="text-xs font-black leading-none font-mono">{el.sym}</span>
                      <span className="text-[9px] font-bold truncate max-w-full opacity-90 dir-rtl">{el.fa}</span>
                    </button>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        playClickSound();
                        setInfoElement(el);
                      }}
                      className="absolute -top-1 -left-1 w-4 h-4 rounded-full bg-black border border-teal-400 text-teal-300 flex items-center justify-center text-[9px] shadow-md hover:bg-teal-500 hover:text-slate-950 transition-colors"
                      title={`اطلاعات علمی ${el.fa}`}
                    >
                      ⓘ
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* VIEW 2: 26 PRESET EXPERIMENTS */}
      {activeTab === 'presets' && (
        <div className="flex-1 flex flex-col space-y-2.5 overflow-y-auto pr-0.5 scrollbar-thin">
          <div className="flex items-center justify-between">
            <span className="text-xs font-black text-teal-300 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>کاتالوگ ۲۶ واکنش کلیدی شیمی</span>
            </span>

            <button
              onClick={runRandomPreset}
              disabled={isBusy || isVesselDestroyed}
              className="flex items-center gap-1 text-[10px] bg-teal-900/60 hover:bg-teal-800/70 text-teal-200 px-2 py-1 rounded-lg border border-teal-600/40 transition-all active:scale-95 disabled:opacity-40"
            >
              <Shuffle className="w-3 h-3 text-amber-300" />
              <span>آزمایش تصادفی</span>
            </button>
          </div>

          {/* Preset Filters */}
          <div className="flex flex-wrap gap-1">
            {[
              { key: 'all', label: 'همه (۲۶)' },
              { key: 'hazard', label: 'واکنش‌دار ☢' },
              { key: 'fire', label: 'سوختن 🔥' },
              { key: 'gas', label: 'گازها 💨' },
              { key: 'crystal', label: 'رسوب/بلور 💎' },
            ].map(cat => (
              <button
                key={cat.key}
                onClick={() => {
                  playClickSound();
                  setPresetCategory(cat.key as any);
                }}
                className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition-all border ${
                  presetCategory === cat.key
                    ? 'bg-teal-500 text-slate-950 border-teal-300 font-extrabold shadow-sm'
                    : 'bg-black/25 text-slate-400 border-white/5 hover:text-slate-200'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* List */}
          <div className="space-y-1.5 flex-1 overflow-y-auto scrollbar-thin pr-0.5">
            {filteredPresetRules.map((rule, idx) => {
              if (!rule) return null;
              return (
                <div
                  key={rule.id}
                  className="p-2.5 rounded-xl bg-black/25 hover:bg-white/[0.04] border border-white/5 hover:border-teal-500/30 transition-all space-y-1"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 truncate">
                      <span className="w-5 h-5 rounded-full bg-teal-600/15 text-teal-300 flex items-center justify-center text-[10px] font-black flex-shrink-0 font-mono">
                        {idx + 1}
                      </span>
                      <span className="font-bold text-xs text-white truncate">{rule.nameFa}</span>
                    </div>

                    <button
                      onClick={() => {
                        playClickSound();
                        onRunPresetRule(rule.reactants);
                      }}
                      disabled={isBusy || isVesselDestroyed}
                      className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-teal-600 to-cyan-600 hover:from-teal-500 hover:to-cyan-500 text-white font-black text-[10px] whitespace-nowrap active:scale-95 transition-all shadow-sm disabled:opacity-30 disabled:pointer-events-none"
                    >
                      اجرا ▶
                    </button>
                  </div>

                  <div className="text-[10px] font-mono text-teal-400 dir-ltr text-right pl-7">
                    {rule.reactants.join(' + ')} → <span className="font-bold text-amber-300">{rule.formula}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* VIEW 3: KNOWLEDGE, SAFETY CARD & HISTORY */}
      {activeTab === 'knowledge' && (
        <div className="flex-1 flex flex-col space-y-3 overflow-y-auto pr-0.5 scrollbar-thin">

          {/* Selected Element Card */}
          {infoElement ? (
            <EducationalSafetyCard
              element={infoElement}
              onClose={() => setInfoElement(null)}
              onSelectNext={() => {
                const idx = elements.findIndex(e => e.z === infoElement.z);
                const nextEl = elements[(idx + 1) % elements.length];
                if (nextEl) setInfoElement(nextEl);
              }}
              onSelectPrev={() => {
                const idx = elements.findIndex(e => e.z === infoElement.z);
                const prevEl = elements[(idx - 1 + elements.length) % elements.length];
                if (prevEl) setInfoElement(prevEl);
              }}
            />
          ) : (
            <div className="p-4 text-center text-xs text-slate-500 border border-dashed border-white/10 rounded-xl">
              برای مشاهده کارت علمی و نکات ایمنی، یک عنصر را از کاتالوگ انتخاب فرمایید.
            </div>
          )}

          {/* History */}
          <div className="glass-card p-3 rounded-2xl bg-black/20 space-y-2">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-300">
              <History className="w-3.5 h-3.5 text-amber-400" />
              <span>تاریخچه آزمایش‌های انجام‌شده</span>
            </div>

            {history.length === 0 ? (
              <div className="text-[11px] text-slate-500 py-2 text-center">
                هنوز آزمایشی ثبت نشده است.
              </div>
            ) : (
              <div className="space-y-1 max-h-40 overflow-y-auto scrollbar-thin">
                {history.map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between p-2 rounded-xl bg-black/25 text-xs border border-white/5"
                  >
                    <div className="flex items-center gap-1.5 truncate">
                      <span className="font-mono font-bold text-amber-300 text-[11px]">{item.syms.join(' + ')}</span>
                      <span className="text-slate-400 text-[10px]">← {item.nameFa}</span>
                    </div>

                    <button
                      onClick={() => {
                        playClickSound();
                        onReplayHistory(item);
                      }}
                      disabled={isBusy || isVesselDestroyed}
                      className="p-1 text-[10px] bg-white/[0.04] hover:bg-white/10 text-slate-300 rounded-lg transition-colors"
                      title="تکرار این آزمایش"
                    >
                      <RotateCcw className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Safety Banner */}
          <div className="text-[10px] text-slate-400 leading-relaxed p-2.5 bg-black/20 rounded-xl border border-white/5 flex items-start gap-2">
            <ShieldCheck className="w-4 h-4 text-teal-400 flex-shrink-0 mt-0.5" />
            <span>
              این محیط شبیه‌ساز آموزشی شیمی بر اساس داده‌های رسمی IUPAC است. همیشه در آزمایشگاه واقعی از عینک ایمنی و نظارت دبیر بهره ببرید.
            </span>
          </div>

        </div>
      )}

    </div>
  );
};
