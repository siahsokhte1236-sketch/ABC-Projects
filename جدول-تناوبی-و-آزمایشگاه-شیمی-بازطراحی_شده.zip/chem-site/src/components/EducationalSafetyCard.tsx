import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChemicalElement } from '../types';
import { CATEGORIES } from '../data/categories';
import { ShieldAlert, BookOpen, Atom, Info, Sparkles, X, ChevronRight, ChevronLeft, FlaskConical } from 'lucide-react';
import { playClickSound } from '../utils/audio';

interface EducationalSafetyCardProps {
  element: ChemicalElement | null;
  onClose: () => void;
  onSelectNext?: () => void;
  onSelectPrev?: () => void;
}

export const EducationalSafetyCard: React.FC<EducationalSafetyCardProps> = ({
  element,
  onClose,
  onSelectNext,
  onSelectPrev,
}) => {
  if (!element) return null;

  const cat = CATEGORIES[element.cat];
  const isDangerous = element.safety.includes('سمی') || element.safety.includes('آتش‌زا') || element.safety.includes('خورنده') || element.safety.includes('خطر');

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 15 }}
        transition={{ type: 'spring', stiffness: 350, damping: 28 }}
        className="glass-card p-4 rounded-2xl border border-teal-500/30 bg-black/60 shadow-2xl space-y-3.5 dir-rtl text-slate-100 relative overflow-hidden"
      >
        {/* Subtle Ambient Background Glow */}
        <div
          className="absolute -top-10 -right-10 w-32 h-32 rounded-full blur-3xl opacity-20 pointer-events-none"
          style={{ backgroundColor: cat.color }}
        />

        {/* Card Top Action Bar */}
        <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-xl bg-teal-500/10 text-teal-400 border border-teal-500/20">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-black text-teal-300">کارت آموزش علمی و ایمنی عنصر</span>
              <span className="text-[10px] text-slate-400 block font-mono">Z = {element.z} | {element.en}</span>
            </div>
          </div>

          <div className="flex items-center gap-1">
            {onSelectPrev && (
              <button
                onClick={() => { playClickSound(); onSelectPrev(); }}
                className="p-1 rounded-lg bg-black/30 border border-white/5 text-slate-300 hover:text-white"
                title="عنصر قبلی"
              >
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            )}
            {onSelectNext && (
              <button
                onClick={() => { playClickSound(); onSelectNext(); }}
                className="p-1 rounded-lg bg-black/30 border border-white/5 text-slate-300 hover:text-white"
                title="عنصر بعدی"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
            )}
            <button
              onClick={() => { playClickSound(); onClose(); }}
              className="p-1.5 rounded-lg bg-black/30 hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Element Main Banner */}
        <div className="flex items-center gap-3 bg-black/25 p-3 rounded-xl border border-white/5">
          <div
            style={{ backgroundColor: cat.color }}
            className="w-14 h-14 rounded-2xl flex flex-col items-center justify-center text-slate-950 font-black shadow-lg flex-shrink-0"
          >
            <span className="text-xl leading-none font-mono">{element.sym}</span>
            <span className="text-[10px] opacity-80 mt-0.5 font-mono">{element.z}</span>
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-black text-white truncate">{element.fa}</h3>
              <span
                style={{ color: cat.textColor, backgroundColor: `${cat.color}22`, borderColor: `${cat.color}55` }}
                className="text-[10px] font-bold px-2 py-0.5 rounded-full border"
              >
                {element.categoryFa}
              </span>
            </div>
            <p className="text-xs text-slate-400 font-medium truncate mt-0.5">{element.en}</p>
          </div>
        </div>

        {/* 🛡️ SAFETY TIPS SECTION (نکات ایمنی و دستورالعمل‌های کارگاهی) */}
        <div className={`p-3 rounded-xl border ${isDangerous ? 'bg-red-950/30 border-red-500/40 text-red-200' : 'bg-amber-950/20 border-amber-500/30 text-amber-200'}`}>
          <div className="flex items-center gap-1.5 font-black text-xs mb-1">
            <ShieldAlert className={`w-4 h-4 ${isDangerous ? 'text-red-400 animate-pulse' : 'text-amber-400'}`} />
            <span>نکات ایمنی و دستورالعمل آزمایشگاهی:</span>
          </div>
          <p className="text-xs leading-relaxed font-semibold">
            {element.safety || 'در شرایط عادی کم‌خطر است؛ اصول اولیه آزمایشگاهی رعایت شود.'}
          </p>
        </div>

        {/* 🔬 SCIENTIFIC DETAILS & DESCRIPTION */}
        <div className="space-y-1.5">
          <div className="flex items-center gap-1 text-xs font-bold text-teal-400">
            <Info className="w-3.5 h-3.5" />
            <span>توضیحات علمی و ویژگی‌ها:</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed bg-black/25 p-2.5 rounded-xl border border-white/5">
            {element.desc}
          </p>
        </div>

        {/* Key Properties Grid */}
        <div className="grid grid-cols-3 gap-1.5 text-center text-[11px]">
          <div className="p-2 rounded-xl bg-black/25 border border-white/5">
            <span className="text-slate-400 block text-[9px]">حالت ماده</span>
            <span className="font-bold text-teal-300">{element.phaseFa}</span>
          </div>
          <div className="p-2 rounded-xl bg-black/25 border border-white/5">
            <span className="text-slate-400 block text-[9px]">جرم اتمی</span>
            <span className="font-bold text-amber-300 dir-ltr inline-block font-mono">{element.mass}</span>
          </div>
          <div className="p-2 rounded-xl bg-black/25 border border-white/5">
            <span className="text-slate-400 block text-[9px]">الکترونگاتیوی</span>
            <span className="font-bold text-cyan-300 dir-ltr inline-block font-mono">{element.eneg || '—'}</span>
          </div>
        </div>

        {/* 💡 APPLICATIONS */}
        {element.uses && element.uses.length > 0 && (
          <div className="space-y-1">
            <div className="flex items-center gap-1 text-[11px] font-bold text-slate-300">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>کاربردهای کاربردی و صنعتی:</span>
            </div>
            <div className="flex flex-wrap gap-1">
              {element.uses.map((use, i) => (
                <span
                  key={i}
                  className="px-2 py-0.5 rounded-lg text-[10px] bg-black/25 border border-white/5 text-slate-300"
                >
                  {use.trim()}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Discovery Footer */}
        {element.by && (
          <div className="text-[10px] text-slate-500 pt-1 border-t border-white/5 flex justify-between">
            <span>کاشف: {element.by}</span>
            <span>سال کشف: {element.year}</span>
          </div>
        )}
      </motion.div>
    </AnimatePresence>
  );
};
