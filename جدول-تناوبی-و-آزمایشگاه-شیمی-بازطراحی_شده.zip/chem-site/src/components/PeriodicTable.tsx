import React, { useMemo } from 'react';
import { ChemicalElement, HeatmapMode } from '../types';
import { ElementTile } from './ElementTile';
import { playClickSound } from '../utils/audio';

interface PeriodicTableProps {
  elements: ChemicalElement[];
  searchQuery: string;
  categoryFilter: string;
  blockFilter: string;
  heatmapMode: HeatmapMode;
  onSelectElement: (element: ChemicalElement) => void;
  onHoverElement: (element: ChemicalElement | null, event?: React.MouseEvent) => void;
}

export const PeriodicTable: React.FC<PeriodicTableProps> = ({
  elements,
  searchQuery,
  categoryFilter,
  blockFilter,
  heatmapMode,
  onSelectElement,
  onHoverElement,
}) => {

  // Calculate heatmap min/max
  const { minVal, maxVal, valMap } = useMemo(() => {
    if (heatmapMode === 'none') {
      return { minVal: 0, maxVal: 0, valMap: new Map<number, number | null>() };
    }

    const map = new Map<number, number | null>();
    const vals: number[] = [];

    elements.forEach(el => {
      let v: number | null = null;
      if (heatmapMode === 'eneg') v = el.eneg;
      else if (heatmapMode === 'ion') v = el.ion && el.ion.length > 0 ? el.ion[0] : null;
      else if (heatmapMode === 'covR') v = el.covR;

      map.set(el.z, v);
      if (v !== null) vals.push(v);
    });

    const min = vals.length > 0 ? Math.min(...vals) : 0;
    const max = vals.length > 0 ? Math.max(...vals) : 1;

    return { minVal: min, maxVal: max, valMap: map };
  }, [elements, heatmapMode]);

  // Match check helper
  const isMatch = (el: ChemicalElement): boolean => {
    if (categoryFilter !== 'all' && el.cat !== categoryFilter) return false;
    if (blockFilter !== 'all' && el.cfg.block !== blockFilter) return false;
    if (searchQuery.trim() !== '') {
      const q = searchQuery.trim().toLowerCase();
      const matchFa = el.fa.toLowerCase().includes(q);
      const matchEn = el.en.toLowerCase().includes(q);
      const matchSym = el.sym.toLowerCase().startsWith(q);
      const matchZ = String(el.z) === q || String(el.z).startsWith(q);
      if (!matchFa && !matchEn && !matchSym && !matchZ) return false;
    }
    return true;
  };

  // Compute grid positions for standard table
  // Grid columns: 1 (Period Num), 2..19 (Group 1..18) -> total 19 columns
  // Grid rows: 1 (Group Num), 2..8 (Period 1..7), 9 (Gap), 10 (Lanthanides), 11 (Actinides)
  const getPosition = (el: ChemicalElement) => {
    if (el.z >= 57 && el.z <= 71) {
      return { row: 10, col: el.z - 57 + 5 };
    }
    if (el.z >= 89 && el.z <= 103) {
      return { row: 11, col: el.z - 89 + 5 };
    }
    return { row: el.period + 1, col: (el.grp || 0) + 1 };
  };

  return (
    <div dir="ltr" style={{ direction: 'ltr', textAlign: 'left' }} className="glass-panel rounded-2xl p-4 sm:p-6 shadow-2xl overflow-x-auto border border-white/5">
      <div className="grid grid-cols-[38px_repeat(18,minmax(58px,1fr))] gap-1.5 min-w-[1180px] select-none">

        {/* Top-Left Corner Header (Group/Period Label) */}
        <div className="col-start-1 row-start-1 flex flex-col items-center justify-center text-[9px] font-bold text-slate-500 leading-tight border-b border-r border-white/5 rounded-tl-lg bg-black/20">
          <span>گروه →</span>
          <span>دوره ↓</span>
        </div>

        {/* Group Numbers Header (1 to 18) */}
        {Array.from({ length: 18 }, (_, i) => i + 1).map((g) => (
          <div
            key={`g-${g}`}
            className="flex items-end justify-center text-xs font-black text-cyan-400/80 pb-1 border-b border-white/5 font-mono"
            style={{ gridColumn: g + 1, gridRow: 1 }}
          >
            {g}
          </div>
        ))}

        {/* Period Numbers Sidebar (1 to 7) */}
        {Array.from({ length: 7 }, (_, i) => i + 1).map((p) => (
          <div
            key={`p-${p}`}
            className="flex items-center justify-center text-xs font-black text-amber-400/80 border-r border-white/5 font-mono"
            style={{ gridColumn: 1, gridRow: p + 1 }}
            title={`دوره ${p}`}
          >
            {p}
          </div>
        ))}

        {/* Placeholders for Lanthanides/Actinides in main grid (Group 3) */}
        <button
          type="button"
          onClick={() => {
            playClickSound();
            const el = document.getElementById('lanthanides-row');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
          style={{ gridColumn: 4, gridRow: 7 }}
          className="flex flex-col items-center justify-center border-2 border-dashed border-fuchsia-500/30 rounded-xl p-1 text-[10px] font-bold text-fuchsia-300/90 hover:border-fuchsia-400/60 hover:bg-fuchsia-500/10 transition-all cursor-pointer dir-rtl"
        >
          <span>۵۷–۷۱</span>
          <span>لانتانیدها</span>
        </button>

        <button
          type="button"
          onClick={() => {
            playClickSound();
            const el = document.getElementById('actinides-row');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
          style={{ gridColumn: 4, gridRow: 8 }}
          className="flex flex-col items-center justify-center border-2 border-dashed border-orange-500/30 rounded-xl p-1 text-[10px] font-bold text-orange-300/90 hover:border-orange-400/60 hover:bg-orange-500/10 transition-all cursor-pointer dir-rtl"
        >
          <span>۸۹–۱۰۳</span>
          <span>اکتینیدها</span>
        </button>

        {/* Lanthanide / Actinide Row Labels */}
        <div
          id="lanthanides-row"
          style={{ gridColumn: '2 / 5', gridRow: 10 }}
          className="flex items-center justify-center border-2 border-dashed border-fuchsia-500/20 rounded-xl p-1.5 text-xs font-black text-fuchsia-300/90 bg-fuchsia-950/10 dir-rtl"
        >
          لانتانیدها (۵۷–۷۱)
        </div>

        <div
          id="actinides-row"
          style={{ gridColumn: '2 / 5', gridRow: 11 }}
          className="flex items-center justify-center border-2 border-dashed border-orange-500/20 rounded-xl p-1.5 text-xs font-black text-orange-300/90 bg-orange-950/10 dir-rtl"
        >
          اکتینیدها (۸۹–۱۰۳)
        </div>

        {/* Gap Row */}
        <div style={{ gridColumn: '1 / -1', gridRow: 9 }} className="h-4" />

        {/* Render 118 Element Tiles */}
        {elements.map((el) => {
          const pos = getPosition(el);
          const matched = isMatch(el);
          const val = valMap.get(el.z) ?? null;

          return (
            <ElementTile
              key={el.z}
              element={el}
              heatmapMode={heatmapMode}
              heatmapValue={val}
              minHeatmapVal={minVal}
              maxHeatmapVal={maxVal}
              isDimmed={!matched}
              onClick={onSelectElement}
              onMouseEnter={onHoverElement}
              onMouseLeave={() => onHoverElement(null)}
              gridColumn={pos.col}
              gridRow={pos.row}
            />
          );
        })}

      </div>
    </div>
  );
};
