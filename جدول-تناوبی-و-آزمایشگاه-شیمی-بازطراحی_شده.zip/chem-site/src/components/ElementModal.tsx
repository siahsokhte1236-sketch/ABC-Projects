import React, { useState, useEffect } from 'react';
import { ChemicalElement } from '../types';
import { CATEGORIES } from '../data/categories';
import { BohrModel } from './BohrModel';
import { IsotopeTable } from './IsotopeTable';
import { X, ChevronRight, ChevronLeft, Download, Share2, Info, Atom, ShieldAlert, Sparkles, Layers, Activity } from 'lucide-react';
import { playClickSound, playSuccessChord } from '../utils/audio';

interface ElementModalProps {
  element: ChemicalElement | null;
  onClose: () => void;
  onNavigate: (direction: 'prev' | 'next') => void;
  hasPrev: boolean;
  hasNext: boolean;
}

type TabKey = 'general' | 'phys' | 'chem' | 'iso' | 'uses' | 'safety';

export const ElementModal: React.FC<ElementModalProps> = ({
  element,
  onClose,
  onNavigate,
  hasPrev,
  hasNext,
}) => {
  const [activeTab, setActiveTab] = useState<TabKey>('general');
  const [copySuccess, setCopySuccess] = useState(false);

  useEffect(() => {
    setActiveTab('general');
  }, [element?.z]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!element) return;
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight' && hasPrev) onNavigate('prev');
      if (e.key === 'ArrowLeft' && hasNext) onNavigate('next');
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [element, onClose, onNavigate, hasPrev, hasNext]);

  if (!element) return null;

  const category = CATEGORIES[element.cat];

  // Helper for Row
  const renderRow = (label: string, value: React.ReactNode) => (
    <div className="flex justify-between items-center py-2 border-b border-white/5 text-xs sm:text-sm">
      <span className="text-slate-400 font-medium">{label}</span>
      <span className="font-bold text-slate-100 dir-ltr text-left font-mono">{value ?? 'نامشخص'}</span>
    </div>
  );

  const fmtTemp = (kelvin: number | null) => {
    if (kelvin === null) return 'نامشخص';
    const celsius = Math.round(kelvin - 273.15);
    return `${kelvin} K (${celsius} °C)`;
  };

  const downloadJSON = () => {
    playClickSound();
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(element, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `element-${element.z}-${element.sym}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const copyShareLink = () => {
    playSuccessChord();
    const url = `${window.location.origin}${window.location.pathname}#element=${element.z}`;
    navigator.clipboard.writeText(url).then(() => {
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/70 backdrop-blur-md animate-in fade-in duration-200">

      {/* Modal Container */}
      <div className="relative w-full max-w-4xl max-h-[92vh] glass-panel rounded-3xl shadow-2xl border border-white/10 overflow-hidden flex flex-col dir-rtl">

        {/* Header Bar */}
        <div className="p-4 bg-black/30 border-b border-white/5 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              disabled={!hasPrev}
              onClick={() => {
                playClickSound();
                onNavigate('prev');
              }}
              className="p-2 rounded-xl bg-white/[0.04] hover:bg-white/10 text-slate-200 disabled:opacity-30 disabled:pointer-events-none transition-all border border-white/5"
              title="عنصر قبلی (کلید راست)"
            >
              <ChevronRight className="w-5 h-5" />
            </button>

            <button
              disabled={!hasNext}
              onClick={() => {
                playClickSound();
                onNavigate('next');
              }}
              className="p-2 rounded-xl bg-white/[0.04] hover:bg-white/10 text-slate-200 disabled:opacity-30 disabled:pointer-events-none transition-all border border-white/5"
              title="عنصر بعدی (کلید چپ)"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={downloadJSON}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-white/[0.04] hover:bg-white/10 text-slate-200 text-xs font-bold rounded-xl border border-white/5 transition-all"
            >
              <Download className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden sm:inline">دانلود JSON</span>
            </button>

            <button
              onClick={copyShareLink}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-white/[0.04] hover:bg-white/10 text-slate-200 text-xs font-bold rounded-xl border border-white/5 transition-all"
            >
              <Share2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>{copySuccess ? 'کپی شد ✓' : 'کپی پیوند'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-white/[0.04] hover:bg-red-500/15 text-slate-400 hover:text-red-400 transition-all border border-white/5"
              title="بستن (Esc)"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Hero Section */}
        <div className="p-5 sm:p-6 bg-gradient-to-b from-black/20 to-transparent border-b border-white/5 flex flex-col sm:flex-row items-center gap-5">
          <div
            className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl flex flex-col items-center justify-center shadow-xl border border-white/30 text-slate-900 flex-shrink-0 relative overflow-hidden"
            style={{ backgroundColor: category.color }}
          >
            <span className="text-3xl sm:text-4xl font-black tracking-tight leading-none font-mono">{element.sym}</span>
            <span className="text-xs font-bold mt-1 opacity-80 font-mono">#{element.z}</span>
          </div>

          <div className="flex-1 text-center sm:text-right">
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mb-1.5">
              <h2 className="text-2xl sm:text-3xl font-black text-white">{element.fa}</h2>
              <span className="text-slate-400 text-sm font-sans dir-ltr">({element.en})</span>
            </div>

            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-1.5 mt-2">
              <span
                className="px-3 py-0.5 rounded-full text-xs font-black shadow-sm text-slate-900"
                style={{ backgroundColor: category.color }}
              >
                {element.categoryFa}
              </span>

              <span className="bg-white/[0.05] border border-white/10 text-slate-300 text-xs px-2.5 py-0.5 rounded-full font-bold">
                بلاک {element.cfg.block}
              </span>

              <span className="bg-white/[0.05] border border-white/10 text-slate-300 text-xs px-2.5 py-0.5 rounded-full font-bold">
                گروه {element.grp ? element.grp : 'سری f'}
              </span>

              <span className="bg-white/[0.05] border border-white/10 text-slate-300 text-xs px-2.5 py-0.5 rounded-full font-bold">
                دوره {element.period}
              </span>

              {element.radioactive && (
                <span className="bg-red-500/15 text-red-300 border border-red-500/30 text-xs px-2.5 py-0.5 rounded-full font-bold">
                  ☢ رادیواکتیو
                </span>
              )}

              {element.synthetic && (
                <span className="bg-amber-500/15 text-amber-300 border border-amber-500/30 text-xs px-2.5 py-0.5 rounded-full font-bold">
                  ⚗ مصنوعی
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 overflow-x-auto p-2 bg-black/40 border-b border-white/5 text-xs font-bold scrollbar-none">
          {[
            { id: 'general', label: 'عمومی و تاریخچه', icon: Info, active: 'bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/15' },
            { id: 'phys', label: 'خواص فیزیکی', icon: Layers, active: 'bg-teal-500 text-slate-950 shadow-lg shadow-teal-500/15' },
            { id: 'chem', label: 'خواص شیمیایی و بور', icon: Atom, active: 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/15' },
            { id: 'iso', label: 'ایزوتوپ‌ها', icon: Activity, active: 'bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/15' },
            { id: 'uses', label: 'کاربردها و فراوانی', icon: Sparkles, active: 'bg-fuchsia-500 text-slate-950 shadow-lg shadow-fuchsia-500/15' },
            { id: 'safety', label: 'نکات ایمنی', icon: ShieldAlert, active: 'bg-rose-500 text-slate-950 shadow-lg shadow-rose-500/15' },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  playClickSound();
                  setActiveTab(tab.id as TabKey);
                }}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl whitespace-nowrap transition-all ${
                  isActive
                    ? `${tab.active} font-extrabold`
                    : 'bg-white/[0.02] text-slate-400 hover:text-slate-200 hover:bg-white/[0.06]'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Modal Body Content */}
        <div className="p-5 sm:p-6 overflow-y-auto flex-1 space-y-4">

          {/* TAB 1: GENERAL */}
          {activeTab === 'general' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="glass-card p-4 rounded-2xl">
                <h3 className="text-sm font-bold text-cyan-400 mb-2 flex items-center gap-1.5">
                  <Info className="w-4 h-4" />
                  <span>معرفی عنصر</span>
                </h3>
                <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">{element.desc}</p>
              </div>

              <div className="glass-card p-4 rounded-2xl">
                <h3 className="text-sm font-bold text-cyan-400 mb-2">مشخصات کلیدی</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6">
                  {renderRow('عدد اتمی', element.z)}
                  {renderRow('جرم اتمی استاندارد', element.mass)}
                  {renderRow('حالت در دمای اتاق', element.phaseFa)}
                  {renderRow('آرایش الکترونی کوتاه', <span className="text-amber-300">{element.cfg.short}</span>)}
                  {renderRow('الکترون‌های ظرفیت', element.cfg.valence)}
                  {renderRow('الکترون‌خواهی', element.ea !== null ? `${element.ea} kJ/mol` : null)}
                </div>
              </div>

              <div className="glass-card p-4 rounded-2xl">
                <h3 className="text-sm font-bold text-cyan-400 mb-2">تاریخچه کشف</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6">
                  {renderRow('سال کشف', element.year)}
                  {renderRow('کاشف(ان)', element.by)}
                  {renderRow('ریشه نام', element.named)}
                  {renderRow('منشاء', element.synthetic ? 'تولید مصنوعی آزمایشگاهی' : 'موجود در طبیعت')}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: PHYSICAL */}
          {activeTab === 'phys' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="glass-card p-4 rounded-2xl">
                <h3 className="text-sm font-bold text-teal-400 mb-3">خواص ترمودینامیکی و فیزیکی</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6">
                  {renderRow('فاز در دمای اتاق', element.phaseFa)}
                  {renderRow('نقطه ذوب', fmtTemp(element.melt))}
                  {renderRow('نقطه جوش', fmtTemp(element.boil))}
                  {renderRow('چگالی', element.dens)}
                  {renderRow('رنگ / ظاهر', element.color)}
                  {renderRow('ساختار بلوری', element.extra.c)}
                  {renderRow('سختی (مقیاس موس)', element.extra.H)}
                  {renderRow('خواص مغناطیسی', element.extra.m)}
                </div>
              </div>

              <div className="glass-card p-4 rounded-2xl">
                <h3 className="text-sm font-bold text-teal-400 mb-3">شعاع اتمی و رسانندگی</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6">
                  {renderRow('شعاع اتمی', element.extra.ar)}
                  {renderRow('شعاع کووالانسی', element.covR ? `${element.covR} pm` : null)}
                  {renderRow('شعاع واندروالس', element.extra.vw ? `${element.extra.vw} pm` : null)}
                  {renderRow('رسانندگی گرمایی', element.extra.k)}
                  {renderRow('ظرفیت گرمایی ویژه', element.extra.h)}
                  {renderRow('سرعت صوت در ماده', element.extra.v)}
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: CHEMICAL & BOHR */}
          {activeTab === 'chem' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

                {/* Bohr Atom Model Interactive */}
                <div className="glass-card p-4 rounded-2xl flex flex-col items-center justify-center text-center">
                  <h3 className="text-sm font-bold text-amber-400 mb-2">مدل پویای بور (لایه‌های الکترونی)</h3>
                  <BohrModel element={element} size={220} />
                </div>

                {/* Configurations & Ionization */}
                <div className="glass-card p-4 rounded-2xl space-y-2">
                  <h3 className="text-sm font-bold text-amber-400 mb-2">آرایش و خواص شیمیایی</h3>
                  {renderRow('الکترونگاتیوی (پاولینگ)', element.eneg)}
                  {renderRow('الکترون‌خواهی', element.ea !== null ? `${element.ea} kJ/mol` : null)}
                  {renderRow('حالت‌های اکسایش', element.ox ? element.ox.join(' ، ') : null)}
                  {renderRow('انرژی یونش نخست', element.ion && element.ion.length > 0 ? `${element.ion[0]} kJ/mol` : null)}

                  <div className="pt-2 border-t border-white/5 space-y-1.5">
                    <span className="text-xs text-slate-400 font-medium">آرایش کامل:</span>
                    <div className="p-2 bg-black/30 rounded-xl font-mono text-[11px] text-amber-300 dir-ltr overflow-x-auto">
                      {element.cfg.full}
                    </div>

                    <span className="text-xs text-slate-400 font-medium">آرایش مختصر:</span>
                    <div className="p-2 bg-black/30 rounded-xl font-mono text-[11px] text-teal-300 dir-ltr overflow-x-auto">
                      {element.cfg.short}
                    </div>
                  </div>
                </div>

              </div>
            </div>
          )}

          {/* TAB 4: ISOTOPES */}
          {activeTab === 'iso' && (
            <div className="animate-in fade-in duration-200">
              <IsotopeTable isotopes={element.iso} symbol={element.sym} synthetic={element.synthetic} />
            </div>
          )}

          {/* TAB 5: USES */}
          {activeTab === 'uses' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="glass-card p-4 rounded-2xl">
                <h3 className="text-sm font-bold text-fuchsia-400 mb-3 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4" />
                  <span>کاربردها در صنعت و زندگی روزمره</span>
                </h3>
                <ul className="space-y-2 text-xs sm:text-sm text-slate-200 list-disc list-inside leading-relaxed">
                  {element.uses.map((useItem, i) => (
                    <li key={i} className="hover:text-fuchsia-300 transition-colors">
                      {useItem}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="glass-card p-4 rounded-2xl">
                <h3 className="text-sm font-bold text-fuchsia-400 mb-2">فراوانی طبیعی</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6">
                  {renderRow('فراوانی در پوسته زمین', element.extra.ac)}
                  {renderRow('فراوانی در گیتی', element.extra.au)}
                </div>
              </div>
            </div>
          )}

          {/* TAB 6: SAFETY */}
          {activeTab === 'safety' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="bg-amber-950/25 p-4 rounded-2xl border border-amber-800/40 space-y-2">
                <h3 className="text-sm font-bold text-amber-400 flex items-center gap-1.5">
                  <ShieldAlert className="w-4 h-4 text-amber-400" />
                  <span>نکات ایمنی و بهداشتی</span>
                </h3>
                <p className="text-xs sm:text-sm text-amber-200/90 leading-relaxed">{element.safety}</p>

                {element.radioactive && (
                  <p className="text-xs text-red-300 bg-red-950/40 p-2 rounded-lg border border-red-800/30 font-bold">
                    ☢ این عنصر پرتوزا (رادیواکتیو) است و کار با آن مستلزم پروتکل‌ها و تجهیزات ویژه حفاظت پرتویی می‌باشد.
                  </p>
                )}

                {element.synthetic && (
                  <p className="text-xs text-amber-300 bg-amber-900/20 p-2 rounded-lg border border-amber-700/30">
                    ⚗ این عنصر به صورت مصنوعی در شتاب‌دهنده‌های ذرات یا راکتورهای هسته‌ای تولید می‌شود.
                  </p>
                )}
              </div>

              <div className="p-3 bg-black/25 rounded-xl border border-white/5 text-[11px] text-slate-400">
                📌 {element.sourceNote}
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
