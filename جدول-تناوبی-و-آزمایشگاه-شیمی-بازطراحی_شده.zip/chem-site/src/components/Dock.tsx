import React from 'react';
import { Table2, FlaskConical } from 'lucide-react';
import { playClickSound } from '../utils/audio';

interface DockProps {
  activeView: 'table' | 'lab';
  onViewChange: (view: 'table' | 'lab') => void;
}

export const Dock: React.FC<DockProps> = ({ activeView, onViewChange }) => {
  return (
    <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-40">
      <div className="glass-panel p-1.5 rounded-full shadow-2xl border border-white/10 flex items-center gap-1.5 backdrop-blur-xl">
        <button
          onClick={() => {
            playClickSound();
            onViewChange('table');
          }}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-full text-xs font-black transition-all ${
            activeView === 'table'
              ? 'bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/30 scale-105'
              : 'text-slate-300 hover:text-white hover:bg-white/10'
          }`}
        >
          <Table2 className="w-4 h-4" />
          <span>جدول تناوبی</span>
        </button>

        <button
          onClick={() => {
            playClickSound();
            onViewChange('lab');
          }}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-full text-xs font-black transition-all ${
            activeView === 'lab'
              ? 'bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/30 scale-105'
              : 'text-slate-300 hover:text-white hover:bg-white/10'
          }`}
        >
          <FlaskConical className="w-4 h-4 text-amber-400" />
          <span>آزمایشگاه ۳بعدی</span>
        </button>
      </div>
    </div>
  );
};
