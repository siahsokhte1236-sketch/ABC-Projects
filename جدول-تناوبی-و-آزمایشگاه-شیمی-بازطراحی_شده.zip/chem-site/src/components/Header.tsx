import React from 'react';
import { FlaskConical, Table2, Sun, Moon, Volume2, VolumeX, Sparkles } from 'lucide-react';
import { playClickSound } from '../utils/audio';

interface HeaderProps {
  activeView: 'table' | 'lab';
  onViewChange: (view: 'table' | 'lab') => void;
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeView,
  onViewChange,
  theme,
  onToggleTheme,
  soundEnabled,
  onToggleSound,
}) => {
  return (
    <header className="relative bg-[var(--void-2)]/95 text-white pt-6 pb-0 px-4 md:px-8 border-b border-white/5 shadow-2xl overflow-hidden">
      {/* Ambient glow — single restrained accent instead of multi-color blobs */}
      <div className="absolute -top-32 -right-20 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-40 -left-20 w-72 h-72 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-5 relative z-10 pb-5">

        {/* Logo and Title */}
        <div className="flex items-center gap-3.5 text-center md:text-right">
          <div className="p-3 bg-white/[0.04] backdrop-blur-md rounded-2xl border border-white/10 shadow-inner flex items-center justify-center text-cyan-300 animate-float">
            <FlaskConical className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2 justify-center md:justify-start flex-wrap">
              <h1 className="text-2xl md:text-[28px] font-black tracking-tight text-white">
                جدول تناوبی عناصر شیمی
              </h1>
              <span className="bg-cyan-500/10 border border-cyan-400/25 text-cyan-300 text-[11px] px-2.5 py-0.5 rounded-full font-bold flex items-center gap-1">
                <Sparkles className="w-3 h-3" /> آزمایشگاه ۳بعدی
              </span>
            </div>
            <p className="text-xs md:text-sm text-slate-400 max-w-2xl mt-1.5 leading-relaxed">
              مشاهده، جستجو و بررسی کامل ۱۱۸ عنصر شیمی؛ خواص فیزیکی و شیمیایی، آرایش الکترونی، ایزوتوپ‌ها و آزمایشگاه سه‌بعدی ترکیبات
            </p>
          </div>
        </div>

        {/* View Switcher and Utilities */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Nav Tabs */}
          <div className="bg-black/30 p-1 rounded-xl border border-white/10 flex items-center gap-1 backdrop-blur-md">
            <button
              onClick={() => {
                playClickSound();
                onViewChange('table');
              }}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-all ${
                activeView === 'table'
                  ? 'bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Table2 className="w-4 h-4" />
              <span>جدول تناوبی</span>
            </button>

            <button
              onClick={() => {
                playClickSound();
                onViewChange('lab');
              }}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-all ${
                activeView === 'lab'
                  ? 'bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <FlaskConical className="w-4 h-4" />
              <span>آزمایشگاه ۳بعدی</span>
            </button>
          </div>

          {/* Sound Toggle */}
          <button
            onClick={() => {
              playClickSound();
              onToggleSound();
            }}
            title={soundEnabled ? 'صدا روشن' : 'صدا خاموش'}
            className="p-2.5 rounded-xl bg-white/[0.04] hover:bg-white/10 border border-white/10 text-white transition-all active:scale-95"
          >
            {soundEnabled ? <Volume2 className="w-5 h-5 text-cyan-300" /> : <VolumeX className="w-5 h-5 text-slate-500" />}
          </button>

          {/* Theme Toggle */}
          <button
            onClick={() => {
              playClickSound();
              onToggleTheme();
            }}
            title={theme === 'dark' ? 'حالت روشن' : 'حالت تاریک'}
            className="p-2.5 rounded-xl bg-white/[0.04] hover:bg-white/10 border border-white/10 text-white transition-all active:scale-95"
          >
            {theme === 'dark' ? <Sun className="w-5 h-5 text-amber-300" /> : <Moon className="w-5 h-5 text-slate-200" />}
          </button>
        </div>

      </div>

      {/* Signature emission-spectrum rule */}
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="spectral-bar spectral-bar-sm" />
      </div>
    </header>
  );
};
