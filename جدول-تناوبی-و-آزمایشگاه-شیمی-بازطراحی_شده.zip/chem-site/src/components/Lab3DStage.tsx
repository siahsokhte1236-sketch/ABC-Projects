import React, { useEffect, useRef, useImperativeHandle, forwardRef } from 'react';
import * as THREE from 'three';
import confetti from 'canvas-confetti';
import { ChemicalElement, ReactionResult } from '../types';
import { CATEGORIES } from '../data/categories';
import { playBubblingSound, playPrecipitateClinkSound, playGasFizzleSound, playSuccessChord, playExplosionSound } from '../utils/audio';

export interface Lab3DStageHandle {
  addToken: (element: ChemicalElement) => void;
  startReaction: (result: ReactionResult, callbacks: { onBurst?: () => void; onDone?: () => void }) => number;
  clearVessel: () => void;
  resetVessel: () => void;
  resetCamera: () => void;
  isDestroyed: () => boolean;
}

interface Lab3DStageProps {
  onFlash?: () => void;
}

export const Lab3DStage = forwardRef<Lab3DStageHandle, Lab3DStageProps>(({ onFlash }, ref) => {
  const mountRef = useRef<HTMLDivElement>(null);

  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);

  const vesselGroupRef = useRef<THREE.Group | null>(null);
  const liquidMatRef = useRef<THREE.MeshStandardMaterial | null>(null);
  const surfaceMatRef = useRef<THREE.MeshStandardMaterial | null>(null);
  const precipitateMatRef = useRef<THREE.MeshStandardMaterial | null>(null);
  const precipitateMeshRef = useRef<THREE.Mesh | null>(null);
  const isDestroyedRef = useRef(false);
  const targetPrecipitateScaleY = useRef(0.001);
  const targetLiquidColor = useRef<THREE.Color>(new THREE.Color(0x1f6feb));
  const reactionActiveRef = useRef<{
    active: boolean;
    time: number;
    duration: number;
    color: THREE.Color;
    animType: string;
    hazard: number;
  }>({
    active: false,
    time: 0,
    duration: 0,
    color: new THREE.Color(0x38bdf8),
    animType: 'steam',
    hazard: 0,
  });

  const tokensRef = useRef<Array<{ g: THREE.Group; vy: number; mode: 'fall' | 'float' | 'sink'; t: number; color: THREE.Color }>>([]);
  const shakeAmpRef = useRef(0);

  const camState = useRef({
    yaw: 0.55, pitch: 0.42, dist: 9.6,
    tyaw: 0.55, tpitch: 0.42, tdist: 9.6,
  });

  // Particle pools
  interface ParticlePool {
    points: THREE.Points;
    max: number;
    cursor: number;
    pos: Float32Array;
    col: Float32Array;
    bc: Float32Array;
    life: Float32Array;
    tl: Float32Array;
    vel: THREE.Vector3[];
    grav: number;
    drag: number;
    dust?: boolean;
    base: THREE.Color;
    emit: (n: number, x: number, y: number, z: number, spd?: number, spread?: number, lifeS?: number, color?: THREE.Color) => void;
    update: (dt: number) => void;
  }

  interface NamedPools {
    bubbles: ParticlePool;
    sparks: ParticlePool;
    steam: ParticlePool;
    smoke: ParticlePool;
    shards: ParticlePool;
    dust: ParticlePool;
  }

  const poolsRef = useRef<ParticlePool[]>([]);
  const namedPoolsRef = useRef<NamedPools | null>(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth || 600;
    const height = container.clientHeight || 400;

    // 1. Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(width, height);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // 2. Scene & Fog
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0b1020);
    scene.fog = new THREE.FogExp2(0x0b1020, 0.04);
    sceneRef.current = scene;

    // 3. Camera
    const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 120);
    cameraRef.current = camera;

    const target = new THREE.Vector3(0, 1.7, 0);

    const applyCam = () => {
      const c = camState.current;
      camera.position.set(
        target.x + c.dist * Math.cos(c.pitch) * Math.sin(c.yaw),
        target.y + c.dist * Math.sin(c.pitch),
        target.z + c.dist * Math.cos(c.pitch) * Math.cos(c.yaw)
      );
      camera.lookAt(target);
    };

    // 4. Lights
    scene.add(new THREE.AmbientLight(0x33415e, 0.85));

    const keyLight = new THREE.DirectionalLight(0xbfd4ff, 1.35);
    keyLight.position.set(4, 8, 5);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.set(1024, 1024);
    scene.add(keyLight);

    const rimLight = new THREE.PointLight(0x38bdf8, 1.1, 34);
    rimLight.position.set(-5, 4, -5);
    scene.add(rimLight);

    const fillLight = new THREE.PointLight(0x7c3aed, 0.45, 26);
    fillLight.position.set(5, 2, 4);
    scene.add(fillLight);

    const reactorLight = new THREE.PointLight(0x4fc3f7, 0.0, 14);
    reactorLight.position.set(0, 2.2, 0);
    scene.add(reactorLight);

    // 5. Stage Platform & Ring
    const platform = new THREE.Mesh(
      new THREE.CylinderGeometry(4.2, 4.7, 0.5, 48),
      new THREE.MeshStandardMaterial({ color: 0x111a2e, roughness: 0.85, metalness: 0.25 })
    );
    platform.position.y = -0.25;
    platform.receiveShadow = true;
    scene.add(platform);

    const pring = new THREE.Mesh(
      new THREE.TorusGeometry(4.2, 0.035, 8, 72),
      new THREE.MeshBasicMaterial({ color: 0x38bdf8 })
    );
    pring.rotation.x = Math.PI / 2;
    pring.position.y = 0.03;
    scene.add(pring);

    // 6. Glass Vessel Group
    const vessel = new THREE.Group();
    scene.add(vessel);
    vesselGroupRef.current = vessel;

    const glassMesh = new THREE.Mesh(
      new THREE.CylinderGeometry(1.15, 1.02, 2.6, 32, 1, true),
      new THREE.MeshPhysicalMaterial({
        color: 0xbfe3ff, metalness: 0, roughness: 0.06,
        transparent: true, opacity: 0.16, side: THREE.DoubleSide, depthWrite: false
      })
    );
    glassMesh.position.y = 1.75;
    vessel.add(glassMesh);

    const vbase = new THREE.Mesh(
      new THREE.CylinderGeometry(1.28, 1.38, 0.18, 32),
      new THREE.MeshPhysicalMaterial({ color: 0x9fc9e8, transparent: true, opacity: 0.35, roughness: 0.12 })
    );
    vbase.position.y = 0.5;
    vessel.add(vbase);

    const vrim = new THREE.Mesh(
      new THREE.TorusGeometry(1.15, 0.05, 10, 42),
      new THREE.MeshPhysicalMaterial({ color: 0xcfe9ff, transparent: true, opacity: 0.5, roughness: 0.1 })
    );
    vrim.rotation.x = Math.PI / 2;
    vrim.position.y = 3.05;
    vessel.add(vrim);

    // Liquid Body & Surface
    const liquidMat = new THREE.MeshStandardMaterial({
      color: 0x1f6feb, transparent: true, opacity: 0.85,
      roughness: 0.25, metalness: 0.1, emissive: 0x0a2a5e, emissiveIntensity: 0.4
    });
    liquidMatRef.current = liquidMat;

    const liquidMesh = new THREE.Mesh(new THREE.CylinderGeometry(1.0, 0.98, 1.2, 32), liquidMat);
    liquidMesh.position.y = 1.15;
    vessel.add(liquidMesh);

    // Precipitate Sediment Layer Mesh at Beaker Base
    const precipitateMat = new THREE.MeshStandardMaterial({
      color: 0xffffff, roughness: 0.8, metalness: 0.1, transparent: true, opacity: 0.95
    });
    precipitateMatRef.current = precipitateMat;

    const precipitateMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.97, 0.96, 0.2, 32), precipitateMat);
    precipitateMesh.position.y = 0.65;
    precipitateMesh.scale.y = 0.001; // hidden initially
    precipitateMeshRef.current = precipitateMesh;
    vessel.add(precipitateMesh);

    const surfaceMat = new THREE.MeshStandardMaterial({
      color: 0x3b82f6, transparent: true, opacity: 0.9,
      emissive: 0x123c8a, emissiveIntensity: 0.5
    });
    surfaceMatRef.current = surfaceMat;

    const surfaceMesh = new THREE.Mesh(new THREE.CircleGeometry(1.0, 32), surfaceMat);
    surfaceMesh.rotation.x = -Math.PI / 2;
    surfaceMesh.position.y = 1.76;
    vessel.add(surfaceMesh);

    // Particle texture
    const particleTex = (() => {
      const canvas = document.createElement('canvas');
      canvas.width = canvas.height = 64;
      const ctx = canvas.getContext('2d')!;
      const grd = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
      grd.addColorStop(0, 'rgba(255,255,255,1)');
      grd.addColorStop(0.4, 'rgba(255,255,255,0.55)');
      grd.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = grd;
      ctx.fillRect(0, 0, 64, 64);
      return new THREE.CanvasTexture(canvas);
    })();

    // Particle Pool Factory
    const makePool = (max: number, opts: { size?: number; color?: number; grav?: number; drag?: number; dust?: boolean; normal?: boolean; opacity?: number; up?: number }): ParticlePool => {
      const pos = new Float32Array(max * 3);
      const col = new Float32Array(max * 3);
      const bc = new Float32Array(max * 3);
      const life = new Float32Array(max);
      const tl = new Float32Array(max);
      const vel: THREE.Vector3[] = [];

      for (let i = 0; i < max; i++) {
        pos[i * 3 + 1] = -999;
        vel.push(new THREE.Vector3());
      }

      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      geo.setAttribute('color', new THREE.BufferAttribute(col, 3));

      const mat = new THREE.PointsMaterial({
        size: opts.size || 0.14,
        map: particleTex,
        transparent: true,
        depthWrite: false,
        vertexColors: true,
        blending: opts.normal ? THREE.NormalBlending : THREE.AdditiveBlending,
        opacity: opts.opacity ?? 1,
      });

      const pts = new THREE.Points(geo, mat);
      pts.frustumCulled = false;
      scene.add(pts);

      const pool: ParticlePool = {
        points: pts,
        max,
        cursor: 0,
        pos, col, bc, life, tl, vel,
        grav: opts.grav || 0,
        drag: opts.drag || 0,
        dust: !!opts.dust,
        base: new THREE.Color(opts.color || 0xffffff),
        emit(n, x, y, z, spd, spread, lifeS, color) {
          for (let k = 0; k < n; k++) {
            const i = this.cursor;
            this.cursor = (this.cursor + 1) % this.max;
            const sp = spread ?? 0.2;
            pos[i * 3] = x + (Math.random() - 0.5) * sp;
            pos[i * 3 + 1] = y + (Math.random() - 0.5) * sp;
            pos[i * 3 + 2] = z + (Math.random() - 0.5) * sp;

            const th = Math.random() * Math.PI * 2;
            const ph = Math.random() * Math.PI;
            const s = (spd || 1) * (0.4 + Math.random() * 0.9);

            vel[i].set(
              Math.sin(ph) * Math.cos(th) * s,
              Math.abs(Math.cos(ph)) * s * (opts.up ?? 1),
              Math.sin(ph) * Math.sin(th) * s
            );

            life[i] = tl[i] = (lifeS || 1) * (0.6 + Math.random() * 0.8);
            const cc = color || this.base;
            bc[i * 3] = cc.r; bc[i * 3 + 1] = cc.g; bc[i * 3 + 2] = cc.b;
            col[i * 3] = cc.r; col[i * 3 + 1] = cc.g; col[i * 3 + 2] = cc.b;
          }
        },
        update(dt) {
          for (let i = 0; i < this.max; i++) {
            if (life[i] <= 0) continue;
            if (this.dust) {
              pos[i * 3 + 1] += dt * 0.12;
              pos[i * 3] += Math.sin(pos[i * 3 + 1] * 0.7 + i) * dt * 0.05;
              if (pos[i * 3 + 1] > 7.5) pos[i * 3 + 1] = 0.2;
              continue;
            }

            life[i] -= dt;
            if (life[i] <= 0) {
              pos[i * 3 + 1] = -999;
              col[i * 3] = col[i * 3 + 1] = col[i * 3 + 2] = 0;
              continue;
            }

            vel[i].y -= this.grav * dt;
            if (this.drag) vel[i].multiplyScalar(Math.max(0, 1 - this.drag * dt));

            pos[i * 3] += vel[i].x * dt;
            pos[i * 3 + 1] += vel[i].y * dt;
            pos[i * 3 + 2] += vel[i].z * dt;

            const f = Math.max(0, life[i] / tl[i]);
            col[i * 3] = bc[i * 3] * f;
            col[i * 3 + 1] = bc[i * 3 + 1] * f;
            col[i * 3 + 2] = bc[i * 3 + 2] * f;
          }
          geo.attributes.position.needsUpdate = true;
          geo.attributes.color.needsUpdate = true;
        }
      };

      return pool;
    };

    const bubblesPool = makePool(160, { size: 0.1, color: 0x9fdcff, grav: -1.6, drag: 0.6 });
    const sparksPool = makePool(220, { size: 0.12, color: 0xffd27a, grav: 5.5, drag: 0.2 });
    const steamPool = makePool(120, { size: 0.34, color: 0x8fb7d9, grav: -0.9, drag: 1.2, opacity: 0.7 });
    const smokePool = makePool(110, { size: 0.5, color: 0x39435a, grav: -0.5, drag: 1.0, normal: true, opacity: 0.55 });
    const shardsPool = makePool(130, { size: 0.16, color: 0xcfe9ff, grav: 8.5, drag: 0.05 });
    const dustPool = makePool(70, { size: 0.05, color: 0x6ea8ff, opacity: 0.5, dust: true });

    for (let i = 0; i < dustPool.max; i++) {
      dustPool.pos[i * 3] = (Math.random() - 0.5) * 13;
      dustPool.pos[i * 3 + 1] = Math.random() * 7;
      dustPool.pos[i * 3 + 2] = (Math.random() - 0.5) * 13;
      dustPool.life[i] = 1;
    }

    poolsRef.current = [bubblesPool, sparksPool, steamPool, smokePool, shardsPool, dustPool];
    namedPoolsRef.current = {
      bubbles: bubblesPool,
      sparks: sparksPool,
      steam: steamPool,
      smoke: smokePool,
      shards: shardsPool,
      dust: dustPool,
    };

    // Mouse/Touch Orbit Controls
    let isDragging = false;
    let px = 0, py = 0;

    const onPointerDown = (e: MouseEvent | TouchEvent) => {
      isDragging = true;
      px = 'clientX' in e ? e.clientX : e.touches[0].clientX;
      py = 'clientY' in e ? e.clientY : e.touches[0].clientY;
    };

    const onPointerMove = (e: MouseEvent | TouchEvent) => {
      if (!isDragging) return;
      const cx = 'clientX' in e ? e.clientX : e.touches[0].clientX;
      const cy = 'clientY' in e ? e.clientY : e.touches[0].clientY;

      const c = camState.current;
      c.tyaw -= (cx - px) * 0.005;
      c.tpitch = Math.min(1.25, Math.max(0.08, c.tpitch + (cy - py) * 0.004));
      px = cx;
      py = cy;
    };

    const onPointerUp = () => { isDragging = false; };
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const c = camState.current;
      c.tdist = Math.min(16, Math.max(5, c.tdist + e.deltaY * 0.005));
    };

    const domEl = renderer.domElement;
    domEl.addEventListener('mousedown', onPointerDown);
    window.addEventListener('mousemove', onPointerMove);
    window.addEventListener('mouseup', onPointerUp);
    domEl.addEventListener('touchstart', onPointerDown, { passive: true });
    domEl.addEventListener('touchmove', onPointerMove, { passive: true });
    domEl.addEventListener('touchend', onPointerUp);
    domEl.addEventListener('wheel', onWheel, { passive: false });

    // Render Animation Loop
    let clock = new THREE.Clock();
    let animId: number;
    let idleT = 0;

    const renderLoop = () => {
      animId = requestAnimationFrame(renderLoop);
      const dt = Math.min(clock.getDelta(), 0.05);
      idleT += dt;

      // Orbit camera interpolation
      const c = camState.current;
      c.yaw += (c.tyaw - c.yaw) * 0.08;
      c.pitch += (c.tpitch - c.pitch) * 0.08;
      c.dist += (c.tdist - c.dist) * 0.08;
      applyCam();

      // Camera shake
      if (shakeAmpRef.current > 0.001) {
        camera.position.x += (Math.random() - 0.5) * shakeAmpRef.current;
        camera.position.y += (Math.random() - 0.5) * shakeAmpRef.current;
        shakeAmpRef.current *= 0.92;
      }

      // Liquid color transition & precipitate growth
      if (liquidMatRef.current) {
        liquidMatRef.current.color.lerp(targetLiquidColor.current, 0.08);
        liquidMatRef.current.emissive.copy(liquidMatRef.current.color).multiplyScalar(0.4);
        if (surfaceMatRef.current) {
          surfaceMatRef.current.color.copy(liquidMatRef.current.color).multiplyScalar(1.2);
          surfaceMatRef.current.emissive.copy(liquidMatRef.current.color).multiplyScalar(0.5);
          surfaceMesh.position.y = 1.76 + Math.sin(idleT * 3.5) * 0.02;
        }
      }

      if (precipitateMeshRef.current) {
        precipitateMeshRef.current.scale.y += (targetPrecipitateScaleY.current - precipitateMeshRef.current.scale.y) * 0.06;
      }

      // Dynamic Scientific Chemical Reaction Visual Effects
      if (reactionActiveRef.current.active) {
        const r = reactionActiveRef.current;
        r.time += dt;

        const isGasOrFire = r.animType === 'gas' || r.animType === 'steam' || r.animType === 'fire' || r.hazard >= 2;
        const isPrecipitateOrCrystal = r.animType === 'crystal' || r.animType === 'color' || r.animType === 'glow';

        shakeAmpRef.current = Math.max(shakeAmpRef.current, r.hazard >= 2 ? 0.12 : 0.04);
        reactorLight.color.copy(r.color);
        reactorLight.intensity = 2.5 + Math.sin(r.time * 20) * 1.8;

        if (isGasOrFire) {
          // Continuous Effervescence & Gas Release
          bubblesPool.emit(8, 0, 0.7 + Math.random() * 0.9, 0, 2.2, 0.38, 0.8, r.color);
          steamPool.emit(5, 0, 1.8, 0, 2.0, 0.45, 1.2, r.color);
          if (r.hazard >= 1) {
            sparksPool.emit(3, 0, 1.8, 0, 2.5, 0.3, 0.6, r.color);
          }
        }

        if (isPrecipitateOrCrystal) {
          // Precipitate Settlement & Crystal Formation
          sparksPool.emit(4, 0, 0.8 + Math.random() * 0.8, 0, 0.8, 0.4, 0.8, r.color);
          bubblesPool.emit(3, 0, 0.8, 0, 1.2, 0.3, 0.6, r.color);
        }

        if (liquidMesh) {
          liquidMesh.scale.y = 1.0 + Math.sin(r.time * 16) * (r.hazard >= 2 ? 0.08 : 0.04);
        }

        if (r.time >= r.duration) {
          r.active = false;
          reactorLight.intensity = 0.5;
          if (liquidMesh) liquidMesh.scale.set(1, 1, 1);
        }
      }

      // Update falling element tokens
      const tokens = tokensRef.current;
      for (let ti = tokens.length - 1; ti >= 0; ti--) {
        const tk = tokens[ti];
        tk.t += dt;
        if (tk.mode === 'fall') {
          tk.vy += 9.5 * dt;
          tk.g.position.y -= tk.vy * dt;
          tk.g.rotation.y += dt * 3;
          if (tk.g.position.y <= 1.85) {
            bubblesPool.emit(12, tk.g.position.x, 1.8, tk.g.position.z, 1.6, 0.3, 0.9, tk.color);
            sparksPool.emit(6, tk.g.position.x, 1.9, tk.g.position.z, 1.2, 0.2, 0.6, tk.color);
            tk.mode = 'sink';
          }
        } else if (tk.mode === 'float') {
          tk.g.position.y -= dt * 0.9;
          tk.g.rotation.y += dt;
          if (tk.g.position.y <= 2.3) {
            tk.mode = 'sink';
            sparksPool.emit(6, tk.g.position.x, 2.3, tk.g.position.z, 0.7, 0.3, 1.0, tk.color);
          }
        } else {
          tk.g.scale.multiplyScalar(Math.max(0.001, 1 - dt * 3));
          tk.g.position.y -= dt * 0.6;
          if (tk.g.scale.x < 0.02) {
            scene.remove(tk.g);
            tokens.splice(ti, 1);
          }
        }
      }

      // Update particle pools
      poolsRef.current.forEach(p => p.update(dt));

      // Ring pulse
      pring.material.color.setHSL(0.55, 0.8, 0.5 + Math.sin(idleT * 1.2) * 0.12);

      renderer.render(scene, camera);
    };

    renderLoop();

    // Resize Handler
    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      if (!w || !h) return;
      renderer.setSize(w, h);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      domEl.removeEventListener('mousedown', onPointerDown);
      window.removeEventListener('mousemove', onPointerMove);
      window.removeEventListener('mouseup', onPointerUp);
      domEl.removeEventListener('touchstart', onPointerDown);
      domEl.removeEventListener('touchmove', onPointerMove);
      domEl.removeEventListener('touchend', onPointerUp);
      domEl.removeEventListener('wheel', onWheel);

      renderer.dispose();
      if (domEl.parentNode) domEl.parentNode.removeChild(domEl);
    };
  }, []);

  // Imperative handle methods
  useImperativeHandle(ref, () => ({
    addToken(element: ChemicalElement) {
      if (isDestroyedRef.current || !sceneRef.current) return;
      const scene = sceneRef.current;

      const group = new THREE.Group();
      const category = CATEGORIES[element.cat];
      const col = new THREE.Color(category ? category.color : '#93c5fd');

      // Create token mesh
      const mat = new THREE.MeshStandardMaterial({
        color: col, metalness: 0.6, roughness: 0.3, emissive: col, emissiveIntensity: 0.3
      });
      const mesh = new THREE.Mesh(new THREE.SphereGeometry(0.26, 20, 20), mat);
      mesh.castShadow = true;
      group.add(mesh);

      // Label sprite
      const canvas = document.createElement('canvas');
      canvas.width = 128; canvas.height = 64;
      const ctx = canvas.getContext('2d')!;
      ctx.font = 'bold 36px Vazirmatn, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = '#ffffff';
      ctx.shadowColor = category ? category.color : '#3b82f6';
      ctx.shadowBlur = 12;
      ctx.fillText(element.sym, 64, 34);

      const texture = new THREE.CanvasTexture(canvas);
      const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: texture, transparent: true }));
      sprite.scale.set(1.15, 0.58, 1);
      sprite.position.y = 0.6;
      group.add(sprite);

      const angle = Math.random() * Math.PI * 2;
      const radius = Math.random() * 0.5;
      group.position.set(Math.cos(angle) * radius, 5.6 + Math.random() * 0.8, Math.sin(angle) * radius);
      scene.add(group);

      const isGas = element.phase === 2 || element.cat === 'g';
      tokensRef.current.push({
        g: group, vy: 0, mode: isGas ? 'float' : 'fall', t: 0, color: col
      });
    },

    startReaction(result: ReactionResult, callbacks: { onBurst?: () => void; onDone?: () => void }) {
      if (isDestroyedRef.current) return 0;
      const rule = result.rule;
      const colorHex = rule.color || '#38bdf8';
      const newColor = new THREE.Color(colorHex);
      targetLiquidColor.current.copy(newColor);

      const isExplosion = rule.anim === 'explosion' || rule.type === 'explosion' || rule.type === 'unstable' || rule.hazard >= 2;

      if (isExplosion) {
        reactionActiveRef.current = {
          active: true,
          time: 0,
          duration: 0.8,
          color: new THREE.Color(0xff2200),
          animType: 'explosion',
          hazard: rule.hazard,
        };

        const pools = namedPoolsRef.current;
        if (pools) {
          pools.shards.emit(220, 0, 1.7, 0, 12.0, 1.5, 2.5, new THREE.Color(0xcfe9ff));
          pools.sparks.emit(280, 0, 1.7, 0, 10.0, 1.4, 2.0, new THREE.Color(0xff6600));
          pools.smoke.emit(150, 0, 1.7, 0, 6.0, 1.0, 3.5);
        }

        shakeAmpRef.current = 0.95;
        playExplosionSound();
        if (onFlash) onFlash();

        setTimeout(() => {
          reactionActiveRef.current.active = false;
          isDestroyedRef.current = true;
          if (vesselGroupRef.current) vesselGroupRef.current.visible = false;
          if (callbacks.onBurst) callbacks.onBurst();
        }, 800);

        return 2600;
      }

      const isPrecipitate = rule.type === 'precipitate' || rule.anim === 'crystal' || rule.type === 'color_change' || rule.anim === 'color' || rule.type === 'crystal';

      if (isPrecipitate) {
        if (precipitateMatRef.current) {
          precipitateMatRef.current.color.copy(newColor);
        }
        targetPrecipitateScaleY.current = 1.0;
      }

      reactionActiveRef.current = {
        active: true,
        time: 0,
        duration: 2.2,
        color: newColor,
        animType: rule.anim || rule.type,
        hazard: rule.hazard,
      };

      const pools = namedPoolsRef.current;
      if (pools) {
        if (rule.anim === 'gas' || rule.type === 'gas') {
          pools.bubbles.emit(40, 0, 1.0, 0, 2.5, 0.4, 1.2, newColor);
          pools.steam.emit(25, 0, 1.8, 0, 2.2, 0.5, 1.5, newColor);
        } else if (rule.anim === 'crystal' || rule.type === 'precipitate') {
          pools.sparks.emit(35, 0, 0.9, 0, 1.2, 0.4, 1.0, newColor);
          pools.bubbles.emit(15, 0, 0.9, 0, 1.0, 0.3, 0.8, newColor);
        } else if (rule.anim === 'fire' || rule.anim === 'glow' || rule.hazard >= 1) {
          pools.sparks.emit(50, 0, 1.8, 0, 3.2, 0.4, 0.8, newColor);
          pools.steam.emit(30, 0, 1.8, 0, 2.5, 0.5, 1.2, newColor);
        } else {
          pools.bubbles.emit(20, 0, 1.0, 0, 1.5, 0.3, 0.8, newColor);
          pools.steam.emit(15, 0, 1.8, 0, 1.5, 0.4, 1.0, newColor);
        }
      }

      if (rule.anim === 'gas' || rule.type === 'gas') {
        playGasFizzleSound(2.2);
        playBubblingSound(2.0);
      } else if (isPrecipitate) {
        playPrecipitateClinkSound();
        playBubblingSound(1.6);
      } else {
        playBubblingSound(1.8);
      }

      playSuccessChord();
      if (rule.hazard === 0) {
        confetti({ particleCount: 60, spread: 70, origin: { y: 0.6 } });
      }

      setTimeout(() => {
        if (callbacks.onDone) callbacks.onDone();
      }, 2200);

      return 2400;
    },

    clearVessel() {
      if (isDestroyedRef.current) return;
      reactionActiveRef.current.active = false;
      targetPrecipitateScaleY.current = 0.001;
      targetLiquidColor.current.set(0x1f6feb);
    },

    resetVessel() {
      isDestroyedRef.current = false;
      reactionActiveRef.current.active = false;
      targetPrecipitateScaleY.current = 0.001;
      if (vesselGroupRef.current) {
        vesselGroupRef.current.visible = true;
        vesselGroupRef.current.scale.set(1, 1, 1);
      }
      targetLiquidColor.current.set(0x1f6feb);
    },

    resetCamera() {
      camState.current.tyaw = 0.55;
      camState.current.tpitch = 0.42;
      camState.current.tdist = 9.6;
    },

    isDestroyed() {
      return isDestroyedRef.current;
    }
  }));

  return (
    <div className="w-full h-full relative overflow-hidden rounded-2xl bg-[var(--void)]">
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />
    </div>
  );
});

Lab3DStage.displayName = 'Lab3DStage';
