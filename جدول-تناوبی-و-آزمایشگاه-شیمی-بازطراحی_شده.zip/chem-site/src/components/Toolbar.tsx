import React from 'react';
import { Search, RotateCcw, Filter, Flame } from 'lucide-react';
import { ElementCategoryKey, HeatmapMode } from '../types';
import { CATEGORIES } from '../data/categories';
import { HeatmapLegend } from './HeatmapLegend';
import { playClickSound } from '../utils/audio';

interface ToolbarProps {
  searchQuery: string;
  onSearchChange: (q: string) => void;
  categoryFilter: ElementCategoryKey | 'all';
  onCategoryFilterChange: (cat: ElementCategoryKey | 'all') => void;
  blockFilter: 's' | 'p' | 'd' | 'f' | 'all';
  onBlockFilterChange: (blk: 's' | 'p' | 'd' | 'f' | 'all') => void;
  heatmapMode: HeatmapMode;
  onHeatmapModeChange: (mode: HeatmapMode) => void;
  onReset: () => void;
  matchCount: number;
  totalCount: number;
}

export const Toolbar: React.FC<ToolbarProps> = ({
  searchQuery,
  onSearchChange,
  categoryFilter,
  onCategoryFilterChange,
  blockFilter,
  onBlockFilterChange,
  heatmapMode,
  onHeatmapModeChange,
  onReset,
  matchCount,
  totalCount,
}) => {
  return (
    <div className="glass-panel rounded-2xl p-4 sm:p-5 shadow-2xl space-y-4 mb-6 transition-all border border-white/5">

      {/* Row 1: Search, Heatmap, Reset */}
      <div className="flex flex-wrap items-center gap-3">

        {/* Search input */}
        <div className="relative flex-1 min-w-[260px]">
          <Search className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 pointer-events-none" />
          <input
            type="search"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="جستجو: نام فارسی، نام انگلیسی، نماد یا عدد اتمی..."
            className="w-full pl-4 pr-10 py-2.5 bg-black/25 border border-white/10 focus:border-cyan-500/60 rounded-xl text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/15 transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => onSearchChange('')}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-xs bg-slate-800/80 hover:bg-slate-700 text-slate-300 rounded-md px-1.5 py-0.5"
            >
              ✕
            </button>
          )}
        </div>

        {/* Heatmap selection */}
        <div className="flex items-center gap-2">
          <label htmlFor="heatmap" className="text-xs font-semibold text-slate-400 flex items-center gap-1.5 min-w-max">
            <Flame className="w-4 h-4 text-amber-400" />
            <span>رنگ‌بندی:</span>
          </label>
          <select
            id="heatmap"
            value={heatmapMode}
            onChange={(e) => {
              playClickSound();
              onHeatmapModeChange(e.target.value as HeatmapMode);
            }}
            className="px-3 py-2.5 bg-black/25 border border-white/10 rounded-xl text-xs sm:text-sm text-slate-200 focus:outline-none focus:border-cyan-500/60 cursor-pointer"
          >
            <option value="none">بر اساس دسته عنصر</option>
            <option value="eneg">الکترونگاتیوی (پاولینگ)</option>
            <option value="ion">انرژی یونش نخست (kJ/mol)</option>
            <option value="covR">شعاع کووالانسی (pm)</option>
          </select>
        </div>

        {/* Reset button */}
        <button
          onClick={() => {
            playClickSound();
            onReset();
          }}
          className="flex items-center gap-1.5 px-3.5 py-2.5 bg-white/[0.03] hover:bg-white/[0.07] text-slate-200 text-xs sm:text-sm font-semibold rounded-xl border border-white/10 transition-all hover:border-cyan-500/40 active:scale-95 min-w-max"
        >
          <RotateCcw className="w-3.5 h-3.5 text-cyan-400" />
          <span>بازنشانی فیلترها</span>
        </button>

      </div>

      {/* Row 2: Category Chips */}
      <div>
        <div className="text-xs font-bold text-slate-400 mb-2 flex items-center gap-1">
          <Filter className="w-3.5 h-3.5 text-cyan-400" />
          <span>دسته‌بندی عناصر (جهت فیلتر کلیک کنید):</span>
        </div>
        <div className="flex flex-wrap gap-1.5">
          <button
            onClick={() => {
              playClickSound();
              onCategoryFilterChange('all');
            }}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all border ${
              categoryFilter === 'all'
                ? 'bg-cyan-500 text-slate-950 border-cyan-300 shadow-lg shadow-cyan-500/15'
                : 'bg-white/[0.02] hover:bg-white/[0.06] text-slate-300 border-white/10'
            }`}
          >
            همه دسته‌ها
          </button>

          {(Object.keys(CATEGORIES) as ElementCategoryKey[]).map((key) => {
            const cat = CATEGORIES[key];
            const isActive = categoryFilter === key;
            return (
              <button
                key={key}
                onClick={() => {
                  playClickSound();
                  onCategoryFilterChange(key);
                }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all border ${
                  isActive
                    ? 'bg-white/[0.06] text-white border-cyan-400/70 ring-1 ring-cyan-500/25 font-bold'
                    : 'bg-black/20 hover:bg-white/[0.05] text-slate-300 border-white/5'
                }`}
              >
                <span
                  className="w-2.5 h-2.5 rounded-full flex-shrink-0 shadow-sm"
                  style={{ backgroundColor: cat.color }}
                />
                <span>{cat.fa}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Row 3: Block Chips & Explanations */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3 pt-2 border-t border-white/5">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-bold text-slate-400">بلاک الکترونی:</span>
          {(['all', 's', 'p', 'd', 'f'] as const).map((blk) => (
            <button
              key={blk}
              onClick={() => {
                playClickSound();
                onBlockFilterChange(blk);
              }}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all border ${
                blockFilter === blk
                  ? 'bg-cyan-500 text-slate-950 border-cyan-300 shadow-md'
                  : 'bg-black/20 hover:bg-white/[0.05] text-slate-400 border-white/5'
              }`}
            >
              {blk === 'all' ? 'همه' : `بلاک ${blk}`}
            </button>
          ))}
        </div>

        {/* Counter summary badge */}
        <div className="text-xs text-slate-400 bg-black/25 px-3 py-1.5 rounded-xl border border-white/5 flex items-center gap-1.5 font-mono">
          <span className="font-['Vazirmatn']">نمایش:</span>
          <span className="font-bold text-cyan-400">{matchCount}</span>
          <span className="font-['Vazirmatn']">از</span>
          <span className="font-bold text-slate-200">{totalCount}</span>
          <span className="font-['Vazirmatn']">عنصر</span>
        </div>
      </div>

      {/* Block Notes */}
      <div className="text-[11px] text-slate-400/90 leading-relaxed bg-black/20 p-2.5 rounded-xl border border-white/5">
        • <strong className="text-slate-300">بلاک s:</strong> گروه‌های ۱ و ۲ به‌همراه H و He •{' '}
        <strong className="text-slate-300">بلاک p:</strong> گروه‌های ۱۳ تا ۱۸ (به‌جز He) •{' '}
        <strong className="text-slate-300">بلاک d:</strong> فلزات واسطه (گروه‌های ۳ تا ۱۲) •{' '}
        <strong className="text-slate-300">بلاک f:</strong> لانتانیدها و اکتینیدها
      </div>

      {/* Heatmap Legend */}
      <HeatmapLegend mode={heatmapMode} />

    </div>
  );
};
