import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ReactionRule } from '../types';

interface ScientificReactionOverlayProps {
  rule: ReactionRule | null;
  isReacting: boolean;
}

export const ScientificReactionOverlay: React.FC<ScientificReactionOverlayProps> = ({
  rule,
  isReacting,
}) => {
  if (!rule) return null;

  const colorHex = rule.color || '#38bdf8';
  const isGas = rule.anim === 'gas' || rule.type === 'gas';
  const isPrecipitate =
    rule.type === 'precipitate' ||
    rule.anim === 'crystal' ||
    rule.type === 'color_change' ||
    rule.anim === 'color' ||
    rule.type === 'crystal';

  // Generate 16 Framer Motion animated rising bubbles
  const bubbles = Array.from({ length: 18 }).map((_, i) => ({
    id: i,
    size: Math.random() * 12 + 6,
    left: Math.random() * 70 + 15, // percent
    delay: (i * 0.12) % 1.5,
    duration: Math.random() * 1.4 + 1.2,
  }));

  // Generate 20 Framer Motion precipitate flakes falling and settling
  const flakes = Array.from({ length: 22 }).map((_, i) => ({
    id: i,
    left: Math.random() * 80 + 10, // percent
    delay: Math.random() * 0.8,
    duration: Math.random() * 1.5 + 1.2,
    size: Math.random() * 8 + 4,
  }));

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden z-20 flex items-center justify-center">
      <AnimatePresence>
        {isReacting && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
            className="relative w-64 h-80 flex flex-col justify-end items-center"
          >
            {/* 1. Fluid Color Morphing Aura (Framer Motion smooth color transition) */}
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{
                scale: [0.95, 1.05, 1],
                opacity: [0.3, 0.65, 0.45],
                backgroundColor: colorHex,
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                repeatType: 'mirror',
                ease: 'easeInOut',
              }}
              className="absolute bottom-12 w-48 h-48 rounded-full blur-2xl opacity-50"
            />

            {/* 2. Rising Effervescence Bubbles Stream (Framer Motion) */}
            {(isGas || isReacting) && (
              <div className="absolute bottom-16 w-36 h-44 overflow-hidden pointer-events-none">
                {bubbles.map((b) => (
                  <motion.div
                    key={b.id}
                    initial={{
                      y: 140,
                      x: 0,
                      opacity: 0,
                      scale: 0.4,
                    }}
                    animate={{
                      y: [-10, -130],
                      x: [0, (b.id % 2 === 0 ? 8 : -8), 0],
                      opacity: [0, 0.9, 0.9, 0],
                      scale: [0.4, 1, 1.2, 0.2],
                    }}
                    transition={{
                      duration: b.duration,
                      repeat: Infinity,
                      delay: b.delay,
                      ease: 'easeInOut',
                    }}
                    style={{
                      left: `${b.left}%`,
                      width: `${b.size}px`,
                      height: `${b.size}px`,
                      backgroundColor: 'rgba(255, 255, 255, 0.75)',
                      boxShadow: `0 0 10px ${colorHex}`,
                    }}
                    className="absolute rounded-full border border-white/60 backdrop-blur-xs"
                  />
                ))}
              </div>
            )}

            {/* 3. Realistic Precipitate Flakes Settling Physics (Framer Motion) */}
            {isPrecipitate && (
              <div className="absolute bottom-10 w-40 h-40 overflow-hidden pointer-events-none">
                {flakes.map((f) => (
                  <motion.div
                    key={f.id}
                    initial={{
                      y: -40,
                      opacity: 0,
                      rotate: 0,
                    }}
                    animate={{
                      y: [0, 110 + (f.id % 5) * 3],
                      x: [0, (f.id % 2 === 0 ? 6 : -6), 0],
                      opacity: [0, 0.9, 1],
                      rotate: [0, 180, 360],
                    }}
                    transition={{
                      duration: f.duration,
                      delay: f.delay,
                      ease: 'easeOut',
                    }}
                    style={{
                      left: `${f.left}%`,
                      width: `${f.size}px`,
                      height: `${f.size}px`,
                      backgroundColor: colorHex,
                      borderColor: '#ffffff',
                    }}
                    className="absolute rounded-sm border border-white/40 shadow-sm opacity-90"
                  />
                ))}

                {/* Sediment Crust Layer forming at bottom */}
                <motion.div
                  initial={{ scaleY: 0, opacity: 0 }}
                  animate={{ scaleY: 1, opacity: 0.95 }}
                  transition={{ duration: 1.8, ease: 'easeOut', delay: 0.4 }}
                  style={{ backgroundColor: colorHex }}
                  className="absolute bottom-1 left-2 right-2 h-4 rounded-b-xl border-t border-white/40 shadow-inner"
                />
              </div>
            )}

            {/* 4. Vapor/Gas Cloud Dispersion Layer */}
            {isGas && (
              <div className="absolute top-8 w-48 h-20 overflow-hidden pointer-events-none flex justify-center">
                {[1, 2, 3].map((idx) => (
                  <motion.div
                    key={idx}
                    initial={{ y: 20, opacity: 0, scale: 0.5 }}
                    animate={{
                      y: [-10, -50],
                      opacity: [0, 0.5, 0],
                      scale: [0.5, 1.6, 2.2],
                    }}
                    transition={{
                      duration: 2.2,
                      repeat: Infinity,
                      delay: idx * 0.6,
                      ease: 'easeOut',
                    }}
                    style={{ backgroundColor: colorHex }}
                    className="absolute w-16 h-12 rounded-full blur-xl opacity-40"
                  />
                ))}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
