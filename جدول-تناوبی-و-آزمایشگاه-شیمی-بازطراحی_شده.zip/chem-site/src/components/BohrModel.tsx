import React from 'react';
import { ChemicalElement } from '../types';

interface BohrModelProps {
  element: ChemicalElement;
  size?: number;
}

export const BohrModel: React.FC<BohrModelProps> = ({ element, size = 260 }) => {
  const shells = element.cfg.shells;
  const baseRadius = 24;
  const step = 16;
  const totalSize = (baseRadius + step * shells.length) * 2 + 24;

  return (
    <div className="flex flex-col items-center justify-center p-3 bg-black/30 rounded-2xl border border-white/5 shadow-inner">
      <svg
        width={size}
        height={size}
        viewBox={`0 0 ${totalSize} ${totalSize}`}
        className="overflow-visible"
        aria-label={`مدل بور اتم ${element.fa}`}
      >
        {/* Glow backdrop */}
        <defs>
          <filter id="nucleus-glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="4" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
          <radialGradient id="electron-grad">
            <stop offset="0%" stopColor="#67e8f9" />
            <stop offset="100%" stopColor="#0891b2" />
          </radialGradient>
        </defs>

        {/* Central Nucleus */}
        <circle
          cx={totalSize / 2}
          cy={totalSize / 2}
          r={14}
          fill="#f59e0b"
          filter="url(#nucleus-glow)"
          className="animate-pulse"
        />
        <text
          x={totalSize / 2}
          y={totalSize / 2 + 4}
          textAnchor="middle"
          fontSize="10"
          fontWeight="bold"
          fill="#7c2d12"
          className="font-mono select-none"
        >
          {element.sym}
        </text>

        {/* Shells & Electrons */}
        {shells.map((electronCount, shellIdx) => {
          const r = baseRadius + step * (shellIdx + 1);
          const duration = 12 + shellIdx * 6; // Rotation speed per shell

          return (
            <g key={`shell-${shellIdx}`} className="animate-spin-slow" style={{ animationDuration: `${duration}s`, transformOrigin: `${totalSize / 2}px ${totalSize / 2}px` }}>
              {/* Shell Ring */}
              <circle
                cx={totalSize / 2}
                cy={totalSize / 2}
                r={r}
                fill="none"
                stroke="#5eead4"
                strokeOpacity="0.3"
                strokeWidth="1.5"
                strokeDasharray="4 2"
              />

              {/* Electrons on Shell */}
              {Array.from({ length: electronCount }).map((_, eIdx) => {
                const angle = (eIdx / electronCount) * Math.PI * 2 - Math.PI / 2;
                const x = totalSize / 2 + r * Math.cos(angle);
                const y = totalSize / 2 + r * Math.sin(angle);

                return (
                  <circle
                    key={`e-${shellIdx}-${eIdx}`}
                    cx={x}
                    cy={y}
                    r={3.5}
                    fill="url(#electron-grad)"
                    stroke="#ffffff"
                    strokeWidth="1"
                    className="shadow-md"
                  >
                    <title>الکترون لایه {shellIdx + 1}</title>
                  </circle>
                );
              })}
            </g>
          );
        })}
      </svg>

      <div className="mt-2 text-[11px] font-bold text-slate-400 flex items-center gap-2">
        <span>تعداد لایه‌ها: <strong className="text-cyan-400">{shells.length}</strong></span>
        <span>•</span>
        <span>الکترون‌های هر لایه: <strong className="text-amber-400 font-mono dir-ltr">{shells.join(' , ')}</strong></span>
      </div>
    </div>
  );
};
