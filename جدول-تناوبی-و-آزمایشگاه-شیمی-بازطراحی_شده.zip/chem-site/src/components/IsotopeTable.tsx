import React, { useState } from 'react';
import { Isotope } from '../types';
import { ArrowUpDown } from 'lucide-react';
import { playClickSound } from '../utils/audio';

interface IsotopeTableProps {
  isotopes: Isotope[];
  symbol: string;
  synthetic: boolean;
}

export const IsotopeTable: React.FC<IsotopeTableProps> = ({ isotopes, symbol, synthetic }) => {
  const [sortAsc, setSortAsc] = useState(true);

  if (!isotopes || isotopes.length === 0) {
    return <p className="text-xs text-slate-400 py-4 text-center">داده معتبری برای ایزوتوپ‌ها ثبت نشده است.</p>;
  }

  const sortedIsotopes = [...isotopes].sort((a, b) => {
    return sortAsc ? a.massNumber - b.massNumber : b.massNumber - a.massNumber;
  });

  return (
    <div className="space-y-2">
      <div className="overflow-x-auto rounded-xl border border-white/5 bg-black/25">
        <table className="w-full text-xs text-right border-collapse">
          <thead>
            <tr className="bg-black/30 text-slate-300 border-b border-white/10">
              <th className="p-2.5 font-bold">ایزوتوپ</th>
              <th
                onClick={() => {
                  playClickSound();
                  setSortAsc(!sortAsc);
                }}
                className="p-2.5 font-bold cursor-pointer hover:text-cyan-400 select-none flex items-center gap-1"
              >
                <span>عدد جرمی</span>
                <ArrowUpDown className="w-3 h-3 text-slate-400" />
              </th>
              <th className="p-2.5 font-bold">وضعیت پایداری</th>
              <th className="p-2.5 font-bold">فراوانی طبیعی</th>
              <th className="p-2.5 font-bold">نیمه‌عمر</th>
              <th className="p-2.5 font-bold">مد‌های واپاشی</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5 text-slate-200">
            {sortedIsotopes.map((iso, idx) => (
              <tr key={idx} className="hover:bg-white/[0.03] transition-colors">
                <td className="p-2.5 font-bold text-amber-300 dir-ltr text-left font-mono">
                  <sup>{iso.massNumber}</sup>{symbol}
                </td>
                <td className="p-2.5 font-mono">{iso.massNumber}</td>
                <td className="p-2.5">
                  {iso.stable ? (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      پایدار
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      رادیواکتیو
                    </span>
                  )}
                </td>
                <td className="p-2.5 font-mono">{iso.naturalAbundance || '—'}</td>
                <td className="p-2.5 font-mono">
                  {iso.stable ? 'نامحدود (پایدار)' : iso.halfLife || '—'}
                </td>
                <td className="p-2.5 font-mono text-slate-400">
                  {iso.decayModes ? iso.decayModes.join(' ، ') : '—'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {synthetic && (
        <p className="text-[11px] text-amber-400/90 bg-amber-950/30 p-2 rounded-lg border border-amber-800/30">
          ⚠️ ایزوتوپ‌های این عنصر مصنوعی بوده و نیمه‌عمر بسیار کوتاهی دارند.
        </p>
      )}
    </div>
  );
};
