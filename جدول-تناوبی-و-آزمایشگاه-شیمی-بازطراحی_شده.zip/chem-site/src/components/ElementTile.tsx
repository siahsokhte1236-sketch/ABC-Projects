import React from 'react';
import { ChemicalElement, HeatmapMode } from '../types';
import { CATEGORIES } from '../data/categories';

interface ElementTileProps {
  element: ChemicalElement;
  heatmapMode: HeatmapMode;
  heatmapValue: number | null;
  minHeatmapVal: number;
  maxHeatmapVal: number;
  isDimmed: boolean;
  onClick: (element: ChemicalElement) => void;
  onMouseEnter: (element: ChemicalElement, event: React.MouseEvent) => void;
  onMouseLeave: () => void;
  gridColumn?: number;
  gridRow?: number;
}

function getHeatmapBgColor(val: number | null, min: number, max: number, mode: HeatmapMode): string {
  if (val === null) return '#475569'; // slate-600
  if (max === min) return '#3b82f6';

  let ratio = (val - min) / (max - min);
  if (mode === 'covR') ratio = 1 - ratio; // Invert so larger radius is red

  // HSL gradient from blue (220) to red (0)
  const hue = 220 - 220 * Math.max(0, Math.min(1, ratio));
  return `hsl(${hue}, 75%, 45%)`;
}

export const ElementTile: React.FC<ElementTileProps> = ({
  element,
  heatmapMode,
  heatmapValue,
  minHeatmapVal,
  maxHeatmapVal,
  isDimmed,
  onClick,
  onMouseEnter,
  onMouseLeave,
  gridColumn,
  gridRow,
}) => {
  const categoryInfo = CATEGORIES[element.cat];

  let tileBg = categoryInfo.color;
  let textColor = '#0f172a';

  if (heatmapMode !== 'none') {
    if (heatmapValue === null) {
      tileBg = '#475569';
      textColor = '#ffffff';
    } else {
      tileBg = getHeatmapBgColor(heatmapValue, minHeatmapVal, maxHeatmapVal, heatmapMode);
      textColor = '#ffffff';
    }
  }

  const style: React.CSSProperties = {
    backgroundColor: tileBg,
    color: textColor,
    gridColumn: gridColumn ? `${gridColumn}` : undefined,
    gridRow: gridRow ? `${gridRow}` : undefined,
  };

  return (
    <button
      type="button"
      onClick={() => onClick(element)}
      onMouseEnter={(e) => onMouseEnter(element, e)}
      onMouseLeave={onMouseLeave}
      onFocus={(e) => onMouseEnter(element, e as unknown as React.MouseEvent)}
      onBlur={onMouseLeave}
      style={style}
      className={`relative flex flex-col items-center justify-between p-1 sm:p-1.5 rounded-lg border border-black/10 shadow-[inset_0_1px_0_rgba(255,255,255,0.25),0_1px_2px_rgba(0,0,0,0.25)] transition-all duration-200 ease-out select-none cursor-pointer group min-h-[58px] sm:min-h-[64px] ${
        isDimmed ? 'opacity-15 grayscale pointer-events-none' : 'hover:scale-[1.12] hover:-translate-y-0.5 hover:z-30 hover:shadow-2xl hover:ring-2 hover:ring-white/80 hover:brightness-105'
      }`}
      aria-label={`${element.fa} (${element.en})، عدد اتمی ${element.z}، دسته ${element.categoryFa}`}
    >
      {/* Top Header: Atomic Number & Block */}
      <div className="w-full flex items-center justify-between text-[10px] sm:text-[11px] font-extrabold leading-none px-0.5 opacity-90 font-mono">
        <span>{element.z}</span>
        <span className="text-[9px] uppercase opacity-70">{element.cfg.block}</span>
      </div>

      {/* Main Symbol */}
      <div className="text-base sm:text-lg font-black tracking-tight leading-none group-hover:scale-105 transition-transform my-0.5 font-mono">
        {element.sym}
      </div>

      {/* Persian Name & Mass */}
      <div className="w-full text-center leading-tight">
        <div className="text-[9px] sm:text-[10px] font-extrabold truncate w-full dir-rtl">
          {element.fa}
        </div>
        <div className="text-[8px] sm:text-[9px] font-mono opacity-80 truncate dir-ltr">
          {element.mass}
        </div>
      </div>

      {/* Radioactive / Synthetic Indicators */}
      <div className="absolute bottom-0.5 right-1 flex items-center gap-0.5 text-[10px]">
        {element.radioactive && <span title="رادیواکتیو">☢</span>}
        {element.synthetic && <span title="مصنوعی">⚗</span>}
      </div>
    </button>
  );
};
