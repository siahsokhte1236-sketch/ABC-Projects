import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ReactionRule } from '../types';
import { Flame, Droplets, Sparkles, Thermometer, Gauge, Zap, Layers, RefreshCw } from 'lucide-react';

interface LabReactionHUDProps {
  rule: ReactionRule | null;
  isReacting: boolean;
  onResetVessel: () => void;
}

export const LabReactionHUD: React.FC<LabReactionHUDProps> = ({
  rule,
  isReacting,
  onResetVessel,
}) => {
  if (!rule) return null;

  // Derive scientific telemetry based on reaction rule
  const isGas = rule.anim === 'gas' || rule.type === 'gas';
  const isPrecipitate = rule.type === 'precipitate' || rule.anim === 'crystal' || rule.type === 'color_change' || rule.anim === 'color';
  const isFireOrGlow = rule.anim === 'fire' || rule.anim === 'glow' || rule.hazard >= 2;
  const isExothermic = rule.hazard >= 1 || isFireOrGlow || isGas;

  const peakTemp = isFireOrGlow ? 185 : isGas ? 78 : isExothermic ? 48 : 25;
  const phValue = rule.id === 'hcl' || rule.id === 'hf' || rule.id === 'hno3' ? 1.5 : rule.id === 'ammonia' ? 11.8 : 7.0;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: -20, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: -20, scale: 0.95 }}
        transition={{ type: 'spring', stiffness: 300, damping: 25 }}
        className="absolute bottom-3 left-3 right-3 sm:left-4 sm:right-auto sm:max-w-[320px] z-30 glass-panel p-2.5 rounded-xl border border-teal-500/30 bg-black/70 shadow-xl backdrop-blur-xl dir-rtl text-slate-100"
      >
        {/* Header Badge */}
        <div className="flex items-center justify-between pb-1.5 mb-2 border-b border-white/10">
          <div className="flex items-center gap-1.5">
            <span
              className="w-2.5 h-2.5 rounded-full animate-ping"
              style={{ backgroundColor: rule.color || '#22d3ee' }}
            />
            <span className="text-[11px] font-black text-cyan-300">
              {isReacting ? '⚡ در حال پیشرفت...' : '✅ تعادل حاصل شد'}
            </span>
          </div>

          <button
            onClick={onResetVessel}
            className="flex items-center gap-1 text-[10px] text-slate-400 hover:text-white px-1.5 py-0.5 rounded-md bg-white/[0.03] border border-white/5 hover:border-white/15 transition-colors"
          >
            <RefreshCw className="w-2.5 h-2.5" />
            <span>پاکسازی</span>
          </button>
        </div>

        {/* Reaction Title & Formula Badge */}
        <div className="space-y-1.5 mb-2">
          <div className="flex items-center justify-between gap-1">
            <h4 className="text-xs font-black text-white truncate">
              {rule.nameFa}
            </h4>

            {/* Type Tag */}
            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-cyan-950/60 text-cyan-300 border border-cyan-600/30 flex-shrink-0">
              {isGas && '💨 خروج گاز'}
              {isPrecipitate && '🧪 رسوب/تغییر رنگ'}
              {isFireOrGlow && '🔥 انگیزش حرارتی'}
              {!isGas && !isPrecipitate && !isFireOrGlow && '✨ واکنش ترکیبی'}
            </span>
          </div>

          {/* Prominent Formula Box */}
          <div className="flex items-center justify-between bg-black/40 px-2.5 py-1 rounded-lg border border-white/5">
            <span className="text-[10px] font-bold text-slate-400">فرمول:</span>
            <span className="text-xs font-mono font-black text-cyan-300 dir-ltr tracking-wide">
              {rule.formula || '—'}
            </span>
          </div>
        </div>

        {/* Experiment Result Summary Box */}
        <div className="p-2 rounded-lg bg-black/30 border border-white/5 mb-2 space-y-0.5">
          <div className="flex items-center gap-1 text-[10px] font-black text-amber-400">
            <Sparkles className="w-3 h-3" />
            <span>خلاصه نتیجه:</span>
          </div>
          <p className="text-[11px] text-slate-200 leading-snug font-medium">
            {rule.desc || 'واکنش با موفقیت انجام شد و محصولات جدید تشکیل شدند.'}
          </p>
        </div>

        {/* Scientific Gauges */}
        <div className="grid grid-cols-2 gap-1.5 mb-2">
          {/* Temperature Gauge */}
          <div className="p-1.5 rounded-lg bg-black/30 border border-white/5 flex items-center gap-1.5">
            <div className="p-1 rounded bg-amber-500/10 text-amber-400">
              <Thermometer className="w-3 h-3" />
            </div>
            <div>
              <div className="text-[9px] text-slate-400">دما</div>
              <div className="text-[10px] font-black text-amber-300 dir-ltr text-right font-mono">
                {isReacting ? `${peakTemp}°C` : '۲۵°C'}
              </div>
            </div>
          </div>

          {/* pH Indicator */}
          <div className="p-1.5 rounded-lg bg-black/30 border border-white/5 flex items-center gap-1.5">
            <div className="p-1 rounded bg-blue-500/10 text-blue-400">
              <Gauge className="w-3 h-3" />
            </div>
            <div>
              <div className="text-[9px] text-slate-400">pH</div>
              <div className="text-[10px] font-black text-blue-300 dir-ltr text-right font-mono">
                {phValue.toFixed(1)} {phValue < 6 ? '(اسیدی)' : phValue > 8 ? '(بازی)' : '(خنثی)'}
              </div>
            </div>
          </div>
        </div>

        {/* Reaction Progress Bar */}
        <div className="space-y-0.5">
          <div className="flex justify-between text-[9px] text-slate-400">
            <span>پیشرفت فرآیند</span>
            <span>{isReacting ? 'در حال انجام...' : '۱۰۰٪'}</span>
          </div>
          <div className="w-full h-1 bg-black/40 rounded-full overflow-hidden border border-white/5">
            <motion.div
              initial={{ width: '0%' }}
              animate={{ width: isReacting ? '85%' : '100%' }}
              transition={{ duration: isReacting ? 1.5 : 0.4, ease: 'easeOut' }}
              className="h-full bg-gradient-to-r from-cyan-500 via-teal-400 to-emerald-400"
            />
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};
