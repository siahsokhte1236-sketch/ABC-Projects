import React, { useRef, useState, useEffect } from 'react';
import { ChemicalElement, ReactionResult, LabHistoryItem } from '../types';
import { Lab3DStage, Lab3DStageHandle } from './Lab3DStage';
import { LabPanel } from './LabPanel';
import { LabReactionHUD } from './LabReactionHUD';
import { ScientificReactionOverlay } from './ScientificReactionOverlay';
import { resolveReaction } from '../data/reactions';
import { playSuccessChord, playWarningSound, playExplosionSound, playClickSound } from '../utils/audio';
import { Maximize2, Minimize2 } from 'lucide-react';

interface Lab3DProps {
  elements: ChemicalElement[];
}

export const Lab3D: React.FC<Lab3DProps> = ({ elements }) => {
  const stageRef = useRef<Lab3DStageHandle>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const [selectedElements, setSelectedElements] = useState<ChemicalElement[]>([]);
  const [isBusy, setIsBusy] = useState(false);
  const [isVesselDestroyed, setIsVesselDestroyed] = useState(false);
  const [lastResult, setLastResult] = useState<ReactionResult | null>(null);
  const [history, setHistory] = useState<LabHistoryItem[]>([]);
  const [flash, setFlash] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    const handleFSChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFSChange);
    return () => document.removeEventListener('fullscreenchange', handleFSChange);
  }, []);

  const toggleFullscreen = async () => {
    playClickSound();
    if (!containerRef.current) return;

    try {
      if (!document.fullscreenElement) {
        if (containerRef.current.requestFullscreen) {
          await containerRef.current.requestFullscreen();
        }
      } else {
        if (document.exitFullscreen) {
          await document.exitFullscreen();
        }
      }
    } catch (e) {
      // Fallback CSS toggle for restricted iframe environments
      setIsFullscreen(prev => !prev);
    }
  };

  const handleAddElement = (el: ChemicalElement) => {
    if (selectedElements.length >= 4 || isBusy || isVesselDestroyed) return;
    setSelectedElements(prev => [...prev, el]);
    if (stageRef.current) {
      stageRef.current.addToken(el);
    }
  };

  const handleRemoveElement = (index: number) => {
    setSelectedElements(prev => prev.filter((_, i) => i !== index));
  };

  const handleClearVessel = () => {
    setSelectedElements([]);
    setLastResult(null);
    if (stageRef.current) {
      stageRef.current.clearVessel();
    }
  };

  const handleResetCamera = () => {
    if (stageRef.current) {
      stageRef.current.resetCamera();
    }
  };

  const handleRepairVessel = () => {
    setIsVesselDestroyed(false);
    setSelectedElements([]);
    setLastResult(null);
    if (stageRef.current) {
      stageRef.current.resetVessel();
    }
  };

  const triggerReaction = (reactants: ChemicalElement[]) => {
    if (reactants.length < 2 || isBusy || isVesselDestroyed) return;
    setIsBusy(true);

    const symbols = reactants.map(e => e.sym);
    const res = resolveReaction(symbols);
    setLastResult(res);

    if (stageRef.current) {
      const duration = stageRef.current.startReaction(res, {
        onBurst: () => {
          setIsVesselDestroyed(true);
          playExplosionSound();
          setIsBusy(false);
        },
        onDone: () => {
          if (res.rule.hazard === 0) {
            playSuccessChord();
          } else {
            playWarningSound();
          }
          setIsBusy(false);
        }
      });

      // Push history
      const historyItem: LabHistoryItem = {
        id: String(Date.now()),
        timestamp: Date.now(),
        syms: symbols,
        nameFa: res.rule.nameFa,
        formula: res.rule.formula,
        color: res.rule.color,
        hazard: res.rule.hazard,
      };

      setHistory(prev => [historyItem, ...prev.slice(0, 9)]);

      if (duration === 0) setIsBusy(false);
    } else {
      setIsBusy(false);
    }
  };

  const handleRunReaction = () => {
    triggerReaction(selectedElements);
  };

  const handleRunPresetRule = (reactantsSyms: string[]) => {
    const matchedElems: ChemicalElement[] = [];
    reactantsSyms.forEach(sym => {
      const found = elements.find(e => e.sym === sym);
      if (found) matchedElems.push(found);
    });

    if (matchedElems.length >= 2) {
      setSelectedElements(matchedElems);
      if (stageRef.current) {
        matchedElems.forEach((el, i) => {
          setTimeout(() => {
            stageRef.current?.addToken(el);
          }, i * 120);
        });
      }
      setTimeout(() => {
        triggerReaction(matchedElems);
      }, matchedElems.length * 120 + 200);
    }
  };

  const handleReplayHistory = (item: LabHistoryItem) => {
    handleRunPresetRule(item.syms);
  };

  return (
    <div
      ref={containerRef}
      className={`transition-all duration-300 flex flex-col lg:flex-row overflow-hidden glass-panel border border-white/10 shadow-2xl ${
        isFullscreen
          ? 'fixed inset-0 z-50 w-screen h-screen rounded-none bg-[var(--void)]'
          : 'relative w-full h-[calc(100vh-140px)] min-h-[550px] rounded-3xl'
      }`}
    >

      {/* 3D Stage View */}
      <div className="flex-1 relative h-full">
        <Lab3DStage
          ref={stageRef}
          onFlash={() => {
            setFlash(true);
            setTimeout(() => setFlash(false), 150);
          }}
        />

        {/* Top Bar over 3D Stage with Presets and Fullscreen Toggle */}
        <div className="absolute top-3 left-3 right-3 z-30 flex items-center justify-between gap-2 dir-rtl">
          {/* Quick-Preset Bar */}
          <div className="flex-1 flex items-center gap-1.5 overflow-x-auto py-1 px-2.5 bg-black/60 backdrop-blur-md rounded-2xl border border-white/10 shadow-xl scrollbar-none">
            <span className="text-[11px] font-black text-cyan-400 whitespace-nowrap pl-1 flex items-center gap-1">
              <span>🌟</span>
              <span className="hidden sm:inline">آزمایش‌های محبوب:</span>
            </span>
            {[
              { name: 'آب (H₂O)', reactants: ['H', 'O'], bg: 'from-cyan-600 to-blue-600' },
              { name: 'نمک (NaCl)', reactants: ['Na', 'Cl'], bg: 'from-amber-600 to-yellow-600' },
              { name: 'اسید فلورید (HF) ☢', reactants: ['H', 'F'], bg: 'from-red-600 to-rose-600' },
              { name: 'آمونیاک (NH₃)', reactants: ['H', 'N'], bg: 'from-teal-600 to-emerald-600' },
              { name: 'منیزیم 🔥', reactants: ['Mg', 'O'], bg: 'from-orange-600 to-amber-600' },
              { name: 'زنگ آهن', reactants: ['Fe', 'O'], bg: 'from-stone-600 to-amber-700' },
              { name: 'فولاد 🛡️', reactants: ['Fe', 'C'], bg: 'from-slate-600 to-zinc-600' },
              { name: 'گزنون ⚡', reactants: ['Xe', 'F'], bg: 'from-fuchsia-600 to-indigo-600' },
            ].map((item, idx) => (
              <button
                key={idx}
                onClick={() => handleRunPresetRule(item.reactants)}
                disabled={isBusy || isVesselDestroyed}
                className={`px-2.5 py-1 rounded-xl text-[10px] font-bold text-white bg-gradient-to-r ${item.bg} hover:brightness-110 whitespace-nowrap shadow-md active:scale-95 transition-all disabled:opacity-40`}
              >
                {item.name}
              </button>
            ))}
          </div>

          {/* Dedicated Fullscreen Toggle Button */}
          <button
            onClick={toggleFullscreen}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-black/60 border border-cyan-500/30 text-cyan-300 hover:text-white hover:bg-cyan-500/20 shadow-lg backdrop-blur-md text-xs font-black transition-all active:scale-95 flex-shrink-0"
            title={isFullscreen ? 'خروج از تمام‌صفحه (Esc)' : 'حالت تمام‌صفحه'}
          >
            {isFullscreen ? (
              <>
                <Minimize2 className="w-4 h-4 text-cyan-400" />
                <span className="hidden sm:inline">خروج</span>
              </>
            ) : (
              <>
                <Maximize2 className="w-4 h-4 text-cyan-400" />
                <span className="hidden sm:inline">تمام‌صفحه</span>
              </>
            )}
          </button>
        </div>

        {/* Flash Overlay */}
        {flash && <div className="absolute inset-0 bg-white z-40 animate-out fade-out duration-150 pointer-events-none" />}

        {/* Destroyed Vessel Shatter Warning & Repair Banner */}
        {isVesselDestroyed && (
          <div className="absolute top-16 left-1/2 -translate-x-1/2 bg-red-600/95 text-white font-black text-xs sm:text-sm px-5 py-2.5 rounded-2xl shadow-2xl border border-white/30 animate-bounce flex items-center gap-3 z-40 dir-rtl">
            <span className="text-lg">💥</span>
            <span>ظرف آزمایشگاه به علت واکنش ناپایدار و غیرمنتظره شکست!</span>
            <button
              onClick={handleRepairVessel}
              className="px-3 py-1 bg-white text-red-700 font-extrabold rounded-xl text-xs hover:bg-slate-100 shadow-md transition-all active:scale-95 cursor-pointer"
            >
              🛠️ بازسازی ظرف
            </button>
          </div>
        )}

        {/* Framer Motion Scientific Reaction Overlay (Color transitions, rising bubbles & precipitate settling) */}
        <ScientificReactionOverlay
          rule={lastResult ? lastResult.rule : null}
          isReacting={isBusy}
        />

        {/* Scientific Reaction Telemetry HUD */}
        <LabReactionHUD
          rule={lastResult ? lastResult.rule : null}
          isReacting={isBusy}
          onResetVessel={handleClearVessel}
        />
      </div>

      {/* Sidebar Control Panel */}
      <LabPanel
        elements={elements}
        selectedElements={selectedElements}
        onAddElement={handleAddElement}
        onRemoveElement={handleRemoveElement}
        onClearVessel={handleClearVessel}
        onResetCamera={handleResetCamera}
        onRepairVessel={handleRepairVessel}
        onRunReaction={handleRunReaction}
        onRunPresetRule={handleRunPresetRule}
        isVesselDestroyed={isVesselDestroyed}
        isBusy={isBusy}
        lastResult={lastResult}
        history={history}
        onReplayHistory={handleReplayHistory}
      />

    </div>
  );
};
