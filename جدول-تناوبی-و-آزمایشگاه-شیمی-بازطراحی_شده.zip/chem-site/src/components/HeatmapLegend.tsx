import React from 'react';
import { HeatmapMode } from '../types';

interface HeatmapLegendProps {
  mode: HeatmapMode;
}

export const HeatmapLegend: React.FC<HeatmapLegendProps> = ({ mode }) => {
  if (mode === 'none') return null;

  const labels: Record<Exclude<HeatmapMode, 'none'>, [string, string]> = {
    eneg: ['الکترونگاتیوی کم (ضعیف)', 'الکترونگاتیوی زیاد (قوی)'],
    ion: ['انرژی یونش نخست کم', 'انرژی یونش نخست زیاد'],
    covR: ['شعاع کووالانسی کوچک', 'شعاع کووالانسی بزرگ'],
  };

  const [minLabel, maxLabel] = labels[mode];

  return (
    <div className="flex flex-col sm:flex-row items-center gap-3 pt-3 border-t border-white/5 text-xs text-slate-300">
      <span className="font-semibold text-slate-400 min-w-max">{minLabel}</span>
      <div className="flex-1 w-full h-3 rounded-full bg-gradient-to-r from-cyan-500 via-emerald-400 via-amber-400 to-rose-500 shadow-inner border border-white/10" />
      <span className="font-semibold text-slate-400 min-w-max">{maxLabel}</span>
    </div>
  );
};
