import React from 'react';
import { ChemicalElement } from '../types';
import { CATEGORIES } from '../data/categories';

interface ElementTooltipProps {
  element: ChemicalElement | null;
  position: { x: number; y: number } | null;
}

export const ElementTooltip: React.FC<ElementTooltipProps> = ({ element, position }) => {
  if (!element || !position) return null;

  const category = CATEGORIES[element.cat];

  // Screen constraint calculation
  const width = 260;
  const height = 180;

  let left = position.x + 16;
  let top = position.y + 16;

  if (typeof window !== 'undefined') {
    if (left + width > window.innerWidth - 12) {
      left = position.x - width - 16;
    }
    if (top + height > window.innerHeight - 12) {
      top = window.innerHeight - height - 12;
    }
  }

  return (
    <div
      style={{ left: `${left}px`, top: `${top}px` }}
      className="fixed z-50 pointer-events-none w-[260px] glass-panel p-3.5 rounded-2xl shadow-2xl border border-white/10 text-xs text-slate-100 animate-in fade-in zoom-in-95 duration-150 dir-rtl"
    >
      {/* Header */}
      <div className="flex items-center justify-between border-b border-white/10 pb-2 mb-2">
        <div className="flex items-center gap-2">
          <span
            className="w-3 h-3 rounded-full flex-shrink-0 shadow-sm"
            style={{ backgroundColor: category.color }}
          />
          <div>
            <span className="font-black text-sm text-white">{element.fa}</span>
            <span className="text-slate-400 text-xs mr-1 font-sans">({element.en})</span>
          </div>
        </div>
        <span className="bg-black/30 text-cyan-400 px-2 py-0.5 rounded-lg text-xs font-mono font-bold">
          #{element.z}
        </span>
      </div>

      {/* Rows */}
      <div className="space-y-1.5 text-slate-300">
        <div className="flex justify-between items-center">
          <span className="text-slate-400 font-medium">نماد / جرم:</span>
          <span className="font-bold text-white dir-ltr font-mono">{element.sym} — {element.mass}</span>
        </div>

        <div className="flex justify-between items-center">
          <span className="text-slate-400 font-medium">دسته:</span>
          <span className="font-semibold text-teal-300">{element.categoryFa}</span>
        </div>

        <div className="flex justify-between items-center">
          <span className="text-slate-400 font-medium">بلاک / دوره:</span>
          <span className="font-semibold text-slate-200">بلاک {element.cfg.block} • دوره {element.period}</span>
        </div>

        <div className="flex justify-between items-center">
          <span className="text-slate-400 font-medium">آرایش الکترونی:</span>
          <span className="font-mono text-[11px] text-amber-300 dir-ltr truncate max-w-[130px]">
            {element.cfg.short}
          </span>
        </div>
      </div>

      <div className="mt-2.5 pt-1.5 border-t border-white/10 text-[10px] text-slate-400 text-center font-medium">
        جهت مشاهده جزئیات کامل و ایزوتوپ‌ها کلیک کنید
      </div>
    </div>
  );
};
