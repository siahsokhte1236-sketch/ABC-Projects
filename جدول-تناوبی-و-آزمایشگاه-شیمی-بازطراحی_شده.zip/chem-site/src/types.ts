export type ElementCategoryKey = 'k' | 'a' | 't' | 'p' | 'm' | 'n' | 'h' | 'g' | 'l' | 'c';

export interface CategoryInfo {
  key: ElementCategoryKey;
  fa: string;
  color: string;
  bgHex: string;
  textColor: string;
  borderHex: string;
}

export interface Isotope {
  massNumber: number;
  stable: boolean;
  naturalAbundance: string | null;
  halfLife: string | null;
  decayModes: string[] | null;
}

export interface ElectronConfig {
  full: string;
  short: string;
  shells: number[];
  valence: number;
  block: 's' | 'p' | 'd' | 'f';
  predicted: boolean;
}

export interface ChemicalElement {
  z: number;
  sym: string;
  en: string;
  fa: string;
  mass: string;
  cat: ElementCategoryKey;
  categoryFa: string;
  grp: number | null;
  period: number;
  phase: number | null; // 0: solid, 1: liquid, 2: gas
  phaseFa: string;
  melt: number | null;
  boil: number | null;
  dens: string;
  eneg: number | null;
  ea: number | null;
  ion: number[] | null;
  ox: string[] | null;
  covR: number | null;
  color: string;
  year: string;
  by: string;
  named: string;
  desc: string;
  uses: string[];
  safety: string;
  iso: Isotope[];
  extra: {
    ac?: string; // Abundance crust
    au?: string; // Abundance universe
    ar?: string; // Atomic radius
    vw?: string; // Van der Waals radius
    k?: string;  // Thermal conductivity
    h?: string;  // Specific heat
    v?: string;  // Speed of sound
    H?: string;  // Hardness
    c?: string;  // Crystal structure
    m?: string;  // Magnetic properties
  };
  cfg: ElectronConfig;
  radioactive: boolean;
  synthetic: boolean;
  sourceNote: string;
}

export type HeatmapMode = 'none' | 'eneg' | 'ion' | 'covR';

export type ReactionAnim =
  | 'steam'
  | 'gas'
  | 'fire'
  | 'glow'
  | 'color'
  | 'crystal'
  | 'electric'
  | 'freeze'
  | 'none'
  | 'explosion';

export type ReactionType =
  | 'safe'
  | 'gas'
  | 'color_change'
  | 'precipitate'
  | 'crystal'
  | 'fire'
  | 'electric'
  | 'freeze'
  | 'glow'
  | 'no_reaction'
  | 'unstable'
  | 'unknown'
  | 'explosion';

export interface ReactionRule {
  id: string;
  reactants: string[];
  formula: string | null;
  nameFa: string;
  type: ReactionType;
  anim: ReactionAnim;
  color: string;
  hazard: 0 | 1 | 2 | 3; // 0: Safe, 1: Warning, 2: Unstable, 3: Explosive
  desc: string;
}

export interface ReactionResult {
  status: 'known' | 'inert' | 'unknown';
  rule: ReactionRule;
  symbols: string[];
}

export interface LabHistoryItem {
  id: string;
  timestamp: number;
  syms: string[];
  nameFa: string;
  formula: string | null;
  color: string;
  hazard: number;
}
